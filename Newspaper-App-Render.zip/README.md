# 📰 समाचार पत्र वितरक एवं हिसाब-किताब प्रबंधन प्रणाली
(Newspaper Distributor & Hawkers Billing Management App)

यह मोबाइल-फ्रेंडली वेब एप्लीकेशन विशेष रूप से समाचार पत्र वितरकों (Newspaper Distributors/Agencies) और हॉकरों (Hawkers) के दैनिक काम, हिसाब-किताब, छुट्टियों की कटौती और मासिक बिलिंग के लिए बनाई गई है।

---

## 🌟 मुख्य विशेषताएं (Key Features)

1. **📊 लाइव डैशबोर्ड (Today's Overview)**
   - कुल ग्राहक, आज वितरित होने वाले अख़बार, कुल बकाया राशि (₹) और इस महीने की वसूली।
   - **प्रेस ऑर्डर शीट:** आज किस अख़बार की कितनी कॉपियां मंगवानी हैं, इसकी तुरंत गणना।

2. **👥 ग्राहक प्रबंधन (Customer Directory)**
   - नाम, मोबाइल नंबर, पता, लाइन/रूट और कई अख़बार एक साथ चुनने की सुविधा (उदा. दैनिक भास्कर + टाइम्स ऑफ इंडिया)।
   - खोज (Search) और लाइन-वार फ़िल्टर।
   - ग्राहक की पूरी खाता-बही (Ledger): बिल, भुगतान और छुट्टियों का इतिहास।

3. **🧾 मासिक बिलिंग एवं WhatsApp शेयर (Monthly Billing & WhatsApp)**
   - एक क्लिक में पूरे महीने का बिल तैयार होना।
   - **WhatsApp बिल:** एक क्लिक में ग्राहक के WhatsApp पर सुंदर हिन्दी संदेश और UPI भुगतान लिंक भेजना।
   - 80mm थर्मल/पर्ची प्रिंट फॉर्मेट में रसीद।

4. **🏖️ छुट्टी / रोक प्रणाली (Vacations & Pause)**
   - ग्राहक जब भी बाहर जाए, उसकी तारीख दर्ज करें।
   - मासिक बिल में उन दिनों का पैसा स्वतः कट जाएगा!

5. **💰 भुगतान एवं डिजिटल रसीद (Payments & Receipts)**
   - Cash, PhonePe, Google Pay, Paytm या बैंक ट्रांसफर द्वारा प्राप्त पेमेंट की एंट्री।
   - तुरंत प्रिंट योग्य रसीद।

6. **🚴‍♂️ हॉकर रूट शीट (Delivery Pocket Sheet)**
   - हर लाइन/हॉकर के लिए अलग वितरण चार्ट जिसे प्रिंट करके हॉकर अपने साथ ले जा सकता है।

7. **💾 डेटा सुरक्षा एवं बैकअप (Offline-First & Backup)**
   - बिना इंटरनेट के भी पूरा ऐप चलता है।
   - सारा डेटा सुरक्षित रखने के लिए JSON बैकअप डाउनलोड और रीस्टोर करने की सुविधा।

8. **💬 लाइव ग्राहक चैट बॉक्स (Customer Live Chat System)**
   - **ग्राहक के लिए ([customer.html](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/customer.html)):** ग्राहक अपने मोबाइल पोर्टल से सीधे एजेंसी को मैसेज भेज सकते हैं। 1-क्लिक बटन जैसे *"आज अख़बार नहीं आया"*, *"बिल रसीद भेजें"*, *"कल 1 एक्स्ट्रा कॉपी देना"*, *"पेमेंट कर दिया"* आदि।
   - **वितरक के लिए ([index.html](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/index.html)):** नया **"💬 ग्राहक चैट"** टैब, जहाँ सभी ग्राहकों की चैट हिस्ट्री, नए संदेशों का लाल बैज, त्वरित उत्तर (Quick Templates), और चैट से सीधे कॉल/WhatsApp/खाता-बही खोलने की सुविधा है।
   - **लाइव सिंक:** दोनों स्क्रीनों के बीच बिना पेज रिफ्रेश किए संदेश तुरंत दिखाई देते हैं।

---

## 🚀 ऐप कैसे खोलें (How to Open):

1. **कंप्यूटर पर वितरक ऐप:** [`Run_App.bat`](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/Run_App.bat) पर डबल-क्लिक करें या सीधे [index.html](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/index.html) खोलें।
2. **ग्राहक पोर्टल ऐप:** [`Run_Customer_App.bat`](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/Run_Customer_App.bat) पर डबल-क्लिक करें या सीधे [customer.html](file:///C:/Users/pc/.gemini/antigravity/scratch/newspaper-distributor-app/customer.html) खोलें।
3. **मोबाइल पर:** इस फ़ोल्डर की फ़ाइलों को किसी भी वेब होस्टिंग (GitHub Pages, Netlify या Vercel) पर डाल दें, जिससे यह मोबाइल पर ऐप की तरह खुल जाएगा!
