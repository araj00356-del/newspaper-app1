/**
 * ग्राहक पोर्टल (Customer Newspaper Portal Application)
 * Fully connected to the Distributor App via shared localStorage.
 */

const CustStore = {
  get(key, fallback = []) {
    const data = localStorage.getItem('np_' + key);
    if (!data) return fallback;
    try {
      return JSON.parse(data);
    } catch (e) {
      return fallback;
    }
  },

  save(key, val) {
    localStorage.setItem('np_' + key, JSON.stringify(val));
  },

  getAgency() {
    const ag = this.get('agency', {
      name: "श्री गणेश न्यूज़पेपर एजेंसी",
      owner: "avinash raj",
      phone: "9876543210",
      address: "दुकान नं. 12, मुख्य बस स्टैंड",
      upiId: "araj00356-2@okaxis",
      tagline: "विश्वसनीय व समय पर दैनिक समाचार पत्र वितरण सेवा"
    });
    // Ensure the new GPay UPI ID is active
    if (!ag.upiId || ag.upiId === 'rajeshagency@upi' || ag.upiId === 'agency@upi') {
      ag.upiId = 'araj00356-2@okaxis';
      this.save('agency', ag);
    }
    return ag;
  },

  getCustomers() {
    return this.get('customers', []);
  },

  getNewspapers() {
    return this.get('newspapers', []);
  },

  getPayments() {
    return this.get('payments', []);
  },

  getVacations() {
    return this.get('vacations', []);
  },

  getRequests() {
    return this.get('customer_requests', []);
  },

  saveRequests(reqs) {
    this.save('customer_requests', reqs);
  },

  saveVacations(vacs) {
    this.save('vacations', vacs);
  },

  getChats() {
    return this.get('chats', []);
  },

  saveChats(chats) {
    this.save('chats', chats);
  }
};

const CustApp = {
  currentTab: 'home',
  customer: null,

  init() {
    this.bindEvents();
    this.checkSession();
    this.updateChatBadges();

    // Live sync for incoming distributor messages
    window.addEventListener('storage', (e) => {
      if (e.key === 'np_chats') {
        this.updateChatBadges();
        if (this.currentTab === 'chat') {
          this.refreshChatIfOpen();
        }
      }
    });

    setInterval(() => {
      this.updateChatBadges();
      if (this.currentTab === 'chat') {
        this.refreshChatIfOpen();
      }
    }, 2000);
  },

  bindEvents() {
    document.querySelectorAll('[data-cust-tab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = e.currentTarget.getAttribute('data-cust-tab');
        this.switchTab(tab);
      });
    });

    const loginForm = document.getElementById('custLoginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const phone = document.getElementById('loginPhoneInput').value.trim();
        this.login(phone);
      });
    }

    // Modal click out
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('cust-modal-overlay') || e.target.classList.contains('cust-modal-close')) {
        this.closeModal();
      }
    });
  },

  checkSession() {
    const agency = CustStore.getAgency();
    document.getElementById('custHeaderAgency').textContent = agency.name;
    document.getElementById('custHeaderTagline').textContent = agency.tagline || 'दैनिक समाचार पत्र सेवा';

    const savedCustId = localStorage.getItem('cust_logged_id');
    if (savedCustId) {
      const custs = CustStore.getCustomers();
      const found = custs.find(c => c.id == savedCustId);
      if (found) {
        this.customer = found;
        this.showCustomerApp();
        return;
      }
    }

    this.showLoginView();
  },

  showLoginView() {
    document.getElementById('loginView').classList.remove('hidden');
    document.getElementById('customerAppView').classList.add('hidden');
    document.getElementById('custBottomNav').classList.add('hidden');
    document.getElementById('headerUserActions').classList.add('hidden');
    this.renderQuickLogins();
  },

  renderQuickLogins() {
    const container = document.getElementById('quickLoginList');
    if (!container) return;
    const custs = CustStore.getCustomers();

    if (custs.length === 0) {
      container.innerHTML = `<p class="text-xs text-slate-400">कोई ग्राहक उपलब्ध नहीं है।</p>`;
      return;
    }

    container.innerHTML = custs.slice(0, 4).map(c => `
      <button type="button" onclick="CustApp.login('${c.phone}')" class="w-full text-left p-2.5 bg-slate-50 hover:bg-sky-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 flex items-center justify-between transition">
        <span>👤 ${c.name}</span>
        <span class="text-sky-600 font-bold font-mono">📱 ${c.phone}</span>
      </button>
    `).join('');
  },

  login(phone) {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const custs = CustStore.getCustomers();
    const found = custs.find(c => c.phone.replace(/[^0-9]/g, '').endsWith(cleanPhone));

    if (!found) {
      alert("यह मोबाइल नंबर पंजीकृत नहीं है! कृपया अपने वितरक से संपर्क करें या सही नंबर दर्ज करें।");
      return;
    }

    this.customer = found;
    localStorage.setItem('cust_logged_id', found.id);
    this.showCustomerApp();
  },

  logout() {
    localStorage.removeItem('cust_logged_id');
    this.customer = null;
    this.showLoginView();
  },

  showCustomerApp() {
    document.getElementById('loginView').classList.add('hidden');
    document.getElementById('customerAppView').classList.remove('hidden');
    document.getElementById('custBottomNav').classList.remove('hidden');
    document.getElementById('headerUserActions').classList.remove('hidden');
    this.switchTab('home');
  },

  switchTab(tabName) {
    this.currentTab = tabName;

    // Refresh current customer data from store
    const custs = CustStore.getCustomers();
    this.customer = custs.find(c => c.id == this.customer.id) || this.customer;

    document.querySelectorAll('[data-cust-tab]').forEach(btn => {
      const match = btn.getAttribute('data-cust-tab') === tabName;
      btn.classList.toggle('text-sky-600', match);
      btn.classList.toggle('text-slate-400', !match);
    });

    this.renderTab(tabName);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  renderTab(tabName) {
    const container = document.getElementById('custContentArea');
    if (!container) return;

    switch (tabName) {
      case 'home':
        container.innerHTML = this.getHomeHTML();
        break;
      case 'chat':
        container.innerHTML = this.getChatHTML();
        this.attachChatEvents();
        break;
      case 'payments':
        container.innerHTML = this.getPaymentsHTML();
        break;
      case 'request':
        container.innerHTML = this.getRequestHTML();
        break;
      case 'vacation':
        container.innerHTML = this.getVacationHTML();
        break;
      case 'help':
        container.innerHTML = this.getHelpHTML();
        break;
      default:
        container.innerHTML = `<div>लोड हो रहा है...</div>`;
    }
  },

  openModal(html) {
    const modalContainer = document.getElementById('custModalContainer');
    if (!modalContainer) return;
    modalContainer.innerHTML = html;
    modalContainer.classList.remove('hidden');
  },

  closeModal() {
    const modalContainer = document.getElementById('custModalContainer');
    if (modalContainer) {
      modalContainer.classList.add('hidden');
      modalContainer.innerHTML = '';
    }
  },

  showToast(msg, type = 'success') {
    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-emerald-600' : 'bg-sky-600';
    toast.className = `fixed top-4 left-4 right-4 z-50 text-white px-4 py-3 rounded-2xl shadow-xl text-center text-sm font-bold ${bgClass}`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 2500);
  },

  // ================= TAB 1: HOME / MY ACCOUNT =================
  getHomeHTML() {
    const c = this.customer;
    const agency = CustStore.getAgency();
    const newspapers = CustStore.getNewspapers();
    const due = parseFloat(c.currentDue) || 0;

    const myPapers = (c.papers || []).map(cp => {
      const paper = newspapers.find(p => p.id == cp.paperId);
      return { ...cp, paper };
    }).filter(cp => cp.paper);

    return `
      <div class="space-y-4">
        <!-- Greeting Card -->
        <div class="bg-gradient-to-r from-sky-600 to-indigo-700 text-white rounded-3xl p-5 shadow-lg relative overflow-hidden">
          <div class="relative z-10">
            <span class="text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-semibold">📍 ${c.address}</span>
            <h2 class="text-2xl font-black mt-2">नमस्ते, ${c.name} जी!</h2>
            <p class="text-xs text-sky-100 mt-0.5">मोबाइल: ${c.phone}</p>
          </div>
        </div>

        <!-- Bill / Due Card -->
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-500 uppercase">वर्तमान कुल बकाया राशि (Total Due)</span>
            <span class="text-xs px-2.5 py-0.5 rounded-full font-bold ${due > 0 ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'}">
              ${due > 0 ? 'देय है' : 'चुकता है ✓'}
            </span>
          </div>

          <div class="flex items-baseline gap-2">
            <span class="text-3xl font-black ${due > 0 ? 'text-red-600' : 'text-emerald-600'}">
              ₹${due.toLocaleString('en-IN')}
            </span>
            ${due > 0 ? '<span class="text-xs text-slate-400">का भुगतान शेष है</span>' : '<span class="text-xs text-emerald-600 font-semibold">कोई बकाया नहीं है</span>'}
          </div>

          ${due > 0 ? `
            <div class="pt-2">
              <button onclick="CustApp.openPaymentModal()" class="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2 text-sm upi-pulse">
                <span>📲 ऑनलाइन भुगतान करें (UPI / QR)</span>
              </button>
            </div>
          ` : `
            <div class="p-3 bg-emerald-50 rounded-2xl text-xs text-emerald-800 text-center font-medium">
              🎉 आपका खाता पूर्णतः अपडेट है। समय पर भुगतान के लिए धन्यवाद!
            </div>
          `}
        </div>

        <!-- Live Chat Quick Access Banner -->
        <div onclick="CustApp.switchTab('chat')" class="bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-3xl p-4 cust-card cursor-pointer active:scale-95 transition flex items-center justify-between shadow-md">
          <div class="flex items-center gap-3">
            <div class="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center text-2xl backdrop-blur-sm">
              💬
            </div>
            <div>
              <h4 class="font-black text-sm">वितरक से सीधे चैट करें (Live Chat)</h4>
              <p class="text-[11px] text-sky-100">अख़बार न मिलने, नया शुरू करने या बिल पर बात करें</p>
            </div>
          </div>
          <span class="text-xs bg-white text-blue-700 font-bold px-3 py-1.5 rounded-xl shadow-sm whitespace-nowrap">
            चैट करें →
          </span>
        </div>

        <!-- Subscribed Newspapers -->
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 space-y-3">
          <div class="flex items-center justify-between">
            <h3 class="font-bold text-slate-800 text-sm">📰 आपके चालू समाचार पत्र</h3>
            <button onclick="CustApp.switchTab('request')" class="text-xs text-sky-600 font-bold hover:underline">
              + नया जोड़ें
            </button>
          </div>

          <div class="space-y-2.5">
            ${myPapers.length === 0 ? '<p class="text-xs text-slate-400">कोई अख़बार चालू नहीं है।</p>' : myPapers.map(item => {
              const p = item.paper;
              const rates = p.ratesByDay || { 0: 6, 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5 };

              return `
                <div class="p-3.5 bg-slate-50 border border-slate-100 rounded-2xl space-y-2">
                  <div class="flex items-center justify-between">
                    <div>
                      <h4 class="font-bold text-slate-800 text-sm">${p.name}</h4>
                      <span class="text-[11px] text-slate-500">${p.language} | प्रतियां: <b>${item.copies || 1}</b></span>
                    </div>
                    <span class="text-xs font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md">चालू</span>
                  </div>

                  <!-- Day-wise rates breakdown chips -->
                  <div class="pt-1 border-t border-slate-200">
                    <span class="text-[10px] text-slate-400 font-bold block mb-1">दिन-वार दरें:</span>
                    <div class="grid grid-cols-7 gap-1 text-[10px] text-center font-medium">
                      <div class="bg-red-50 p-1 rounded-md text-red-700">रवि<br><b>₹${rates[0]}</b></div>
                      <div class="bg-white p-1 rounded-md text-slate-700">सोम<br><b>₹${rates[1]}</b></div>
                      <div class="bg-white p-1 rounded-md text-slate-700">मंगल<br><b>₹${rates[2]}</b></div>
                      <div class="bg-amber-50 p-1 rounded-md text-amber-700">बुध<br><b>₹${rates[3]}</b></div>
                      <div class="bg-white p-1 rounded-md text-slate-700">गुरु<br><b>₹${rates[4]}</b></div>
                      <div class="bg-white p-1 rounded-md text-slate-700">शुक्र<br><b>₹${rates[5]}</b></div>
                      <div class="bg-blue-50 p-1 rounded-md text-blue-700">शनि<br><b>₹${rates[6]}</b></div>
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Quick actions banner -->
        <div class="grid grid-cols-3 gap-2.5">
          <div onclick="CustApp.switchTab('vacation')" class="bg-purple-50 p-3 rounded-2xl border border-purple-100 cursor-pointer active:scale-95 transition text-center shadow-sm">
            <div class="text-xl mb-1">🏖️</div>
            <div class="text-xs font-bold text-purple-900">छुट्टी / रोक</div>
            <div class="text-[10px] text-purple-600 mt-0.5">अख़बार रोकें</div>
          </div>

          <div onclick="CustApp.switchTab('payments')" class="bg-emerald-50 p-3 rounded-2xl border border-emerald-100 cursor-pointer active:scale-95 transition text-center shadow-sm">
            <div class="text-xl mb-1">🧾</div>
            <div class="text-xs font-bold text-emerald-900">रसीदें</div>
            <div class="text-[10px] text-emerald-600 mt-0.5">भुगतान देखें</div>
          </div>

          <div onclick="CustApp.openFeedbackModal()" class="bg-amber-50 p-3 rounded-2xl border border-amber-200 cursor-pointer active:scale-95 transition text-center shadow-sm">
            <div class="text-xl mb-1">⭐</div>
            <div class="text-xs font-bold text-amber-900">फीडबैक</div>
            <div class="text-[10px] text-amber-600 mt-0.5">रेटिंग भेजें</div>
          </div>
        </div>
      </div>
    `;
  },

  // Payment Options Modal with Avinash Raj's Official Google Pay UPI QR Code
  openPaymentModal(customAmount = null) {
    const c = this.customer;
    const agency = CustStore.getAgency();
    const totalDue = parseFloat(c.currentDue) || 0;
    const payAmount = customAmount !== null ? parseFloat(customAmount) : (totalDue > 0 ? totalDue : 100);
    const upiId = "araj00356-2@okaxis";
    const payeeName = "avinash raj";

    // Direct Mobile UPI Intent Link with Exact Amount
    const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${payAmount}&cu=INR&tn=${encodeURIComponent(c.name + ' Newspaper Bill')}`;

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 cust-modal-overlay bg-black/60 backdrop-blur-sm overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-sm w-full p-5 text-center space-y-3.5 my-auto max-h-[94vh] overflow-y-auto">
          <!-- Header -->
          <div class="flex items-center justify-between pb-2 border-b border-slate-100">
            <div class="flex items-center gap-2">
              <span class="text-xl">📲</span>
              <h3 class="font-black text-slate-800 text-base">ऑनलाइन भुगतान (UPI QR कोड)</h3>
            </div>
            <button class="cust-modal-close text-slate-400 hover:text-slate-600 font-bold text-lg p-1">✕</button>
          </div>

          <!-- Amount Box & Selector -->
          <div class="bg-gradient-to-r from-emerald-50 to-teal-50 p-3 rounded-2xl border border-emerald-200 text-center">
            <span class="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">भुगतान की जाने वाली राशि:</span>
            <div class="flex items-center justify-center gap-2">
              <span class="text-2xl font-black text-emerald-700">₹</span>
              <input 
                type="number" 
                id="qrCustomAmountInput" 
                value="${payAmount}" 
                min="1" 
                max="50000"
                class="w-32 py-1 px-2 text-2xl font-black text-center text-emerald-700 bg-white border-2 border-emerald-400 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
              >
              <button 
                type="button" 
                onclick="CustApp.updateModalQR()" 
                class="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition shadow-sm"
              >
                अपडेट ✓
              </button>
            </div>
            ${totalDue > 0 ? `
              <p class="text-[11px] text-emerald-700 mt-1 font-medium">कुल बकाया बिल: <b>₹${totalDue}</b></p>
            ` : ''}
          </div>

          <!-- Official Avinash Raj QR Code Card -->
          <div class="p-2.5 bg-white rounded-3xl border-2 border-emerald-400 shadow-md inline-block mx-auto max-w-[270px]">
            <img 
              src="upi_qr.jpg" 
              alt="avinash raj Google Pay UPI QR Code" 
              class="w-full rounded-2xl object-contain shadow-sm border border-slate-100"
            >
          </div>

          <!-- UPI ID Copy Info Box -->
          <div class="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-left space-y-1">
            <div class="flex items-center justify-between text-[11px]">
              <span class="text-slate-400 font-bold uppercase">प्राप्तकर्ता (Payee):</span>
              <span class="font-extrabold text-slate-800">avinash raj</span>
            </div>
            <div class="flex items-center justify-between pt-1 border-t border-slate-200">
              <span class="font-mono font-black text-slate-800 text-xs select-all">${upiId}</span>
              <button onclick="navigator.clipboard.writeText('${upiId}'); CustApp.showToast('UPI ID कॉपी हो गई!');" class="text-xs text-sky-700 font-bold bg-white px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 shadow-sm transition">
                📋 कॉपी
              </button>
            </div>
          </div>

          <!-- Mobile 1-Tap Pay Direct Button -->
          <div>
            <a 
              id="modalDirectUpiLink" 
              href="${upiUrl}" 
              class="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2 text-xs sm:text-sm"
            >
              <span>📱 सीधे मोबाइल UPI ऐप (GPay / PhonePe) से भुगतान करें</span>
            </a>
            <p class="text-[10px] text-slate-400 mt-1">मोबाइल में Google Pay, PhonePe या Paytm अपने आप खुल जाएगा</p>
          </div>

          <!-- After Payment Confirmations -->
          <div class="space-y-2 pt-1 border-t border-slate-100">
            <button 
              type="button" 
              onclick="CustApp.sendPaymentChatMessage(${payAmount})" 
              class="w-full py-2.5 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5"
            >
              <span>💬</span>
              <span>पेमेंट के बाद वितरक को चैट पर सूचित करें</span>
            </button>

            <button 
              type="button" 
              onclick="CustApp.notifyDistributorPayment(${payAmount})" 
              class="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-[11px] transition flex items-center justify-center gap-1"
            >
              <span>📲 WhatsApp पर रसीद मांगें</span>
            </button>
          </div>
        </div>
      </div>
    `;

    this.openModal(html);
  },

  updateModalQR() {
    const input = document.getElementById('qrCustomAmountInput');
    const newAmt = input ? parseFloat(input.value) || 1 : 1;
    this.openPaymentModal(newAmt);
  },

  renderOfflineQRCode(upiUrl) {
    if (typeof QRCode !== 'undefined') {
      const container = document.getElementById('modalQrCanvasContainer');
      if (container) {
        container.innerHTML = '';
        try {
          new QRCode(container, {
            text: upiUrl,
            width: 195,
            height: 195,
            colorDark: "#0f172a",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.M
          });
        } catch (e) {
          console.log("QRCodejs render fallback", e);
          const qrServerUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(upiUrl)}&margin=4`;
          container.innerHTML = `<img src="${qrServerUrl}" alt="QR Code" class="w-48 h-48 rounded-xl object-contain">`;
        }
      }
    }
  },

  sendPaymentChatMessage(amt) {
    this.closeModal();
    const msg = `💰 [ऑनलाइन भुगतान]: मैंने ₹${amt} का UPI / QR कोड द्वारा भुगतान कर दिया है। कृपया खाता चेक करके रसीद अपडेट करें। धन्यवाद! 🧾`;
    this.switchTab('chat');
    this.sendChatMessage(msg);
  },

  notifyDistributorPayment(amt) {
    const agency = CustStore.getAgency();
    const c = this.customer;
    const msg = `नमस्ते ${agency.owner} जी, मैंने अपने अख़बार खाते (${c.name}, ${c.address}) का ₹${amt} का भुगतान UPI द्वारा कर दिया है। कृपया रसीद अपडेट करें। धन्यवाद!`;
    const cleanPhone = agency.phone.replace(/[^0-9]/g, '');
    const phoneWithCode = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;
    window.open(`https://wa.me/${phoneWithCode}?text=${encodeURI(msg)}`, '_blank');
  },

  // ================= TAB 2: PAYMENT HISTORY & QR CODE =================
  getPaymentsHTML() {
    const c = this.customer;
    const allPayments = CustStore.getPayments();
    const myPayments = allPayments.filter(p => p.customerId == c.id);
    const due = parseFloat(c.currentDue) || 0;
    const agency = CustStore.getAgency();
    const upiId = agency.upiId || 'rajeshagency@upi';
    const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(agency.name)}&am=${due}&cu=INR&tn=${encodeURIComponent(c.name + ' Newspaper Bill')}`;
    const qrServerUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiUrl)}&margin=4`;

    return `
      <div class="space-y-4">
        <!-- Online Payment QR Box Card -->
        <div class="bg-gradient-to-r from-emerald-600 via-teal-700 to-sky-700 text-white rounded-3xl p-5 cust-card shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
          <div class="text-center sm:text-left">
            <span class="text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-semibold">
              ${due > 0 ? 'वर्तमान देय राशि' : 'खाता चुकता है ✓'}
            </span>
            <div class="text-3xl font-black mt-1">₹${due}</div>
            <p class="text-xs text-emerald-100 mt-0.5">UPI QR कोड स्कैन करके सीधे ऑनलाइन भुगतान करें</p>
          </div>
          <button onclick="CustApp.openPaymentModal()" class="w-full sm:w-auto px-5 py-3 bg-white text-emerald-800 font-extrabold rounded-2xl shadow hover:bg-emerald-50 active:scale-95 transition text-xs sm:text-sm flex items-center justify-center gap-2 upi-pulse flex-shrink-0">
            <span>📷 QR कोड खोलें / स्कैन करें</span>
          </button>
        </div>

        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100">
          <div class="flex items-center justify-between mb-3">
            <h3 class="font-bold text-slate-800 text-base">💰 भुगतान इतिहास (Payment Receipts)</h3>
            <span class="text-xs text-slate-500 font-medium">कुल: ${myPayments.length} भुगतान</span>
          </div>

          ${myPayments.length === 0 ? `
            <div class="p-8 text-center text-slate-400">
              <div class="text-3xl mb-1">📜</div>
              <p class="text-xs">अभी तक कोई भुगतान दर्ज नहीं है।</p>
            </div>
          ` : `
            <div class="space-y-2.5">
              ${myPayments.map(p => `
                <div class="p-3.5 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-between">
                  <div>
                    <div class="text-xs font-bold text-slate-800">रसीद सं: ${p.receiptNo}</div>
                    <div class="text-[11px] text-slate-500">तारीख: ${p.date} | ${p.mode}</div>
                    ${p.note ? `<div class="text-[10px] text-slate-400 italic">नोट: ${p.note}</div>` : ''}
                  </div>
                  <div class="text-right">
                    <div class="text-base font-black text-emerald-700">₹${p.amount}</div>
                    <span class="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold">सत्यापित</span>
                  </div>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;
  },

  // ================= TAB 3: NEW NEWSPAPER / REQUEST =================
  getRequestHTML() {
    const newspapers = CustStore.getNewspapers();
    const existingPaperIds = (this.customer.papers || []).map(p => p.paperId);
    const requests = CustStore.getRequests().filter(r => r.customerId == this.customer.id);

    return `
      <div class="space-y-4">
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100">
          <h3 class="font-bold text-slate-800 text-base">➕ नया समाचार पत्र / पत्रिका शुरू कराएं</h3>
          <p class="text-xs text-slate-500 mt-1">आप अपनी पसंद का कोई भी अतिरिक्त अख़बार घर मंगाने के लिए यहाँ से अनुरोध भेज सकते हैं।</p>
        </div>

        <!-- Available Catalog -->
        <div class="space-y-3">
          ${newspapers.map(np => {
            const isAlreadyActive = existingPaperIds.includes(np.id);
            const rates = np.ratesByDay || { 0: 6, 1: 5 };

            return `
              <div class="bg-white p-4 rounded-3xl border border-slate-100 cust-card space-y-2.5">
                <div class="flex items-center justify-between">
                  <div>
                    <h4 class="font-bold text-slate-800 text-base">${np.name}</h4>
                    <span class="text-xs text-slate-500">${np.language}</span>
                  </div>
                  ${isAlreadyActive ? `
                    <span class="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">पहले से चालू है ✓</span>
                  ` : `
                    <button onclick="CustApp.openRequestModal(${np.id})" class="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition">
                      + शुरू करवाएं
                    </button>
                  `}
                </div>

                <div class="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl flex items-center justify-between">
                  <span>सामान्य दैनिक दर: <b>₹${rates[1] || np.dailyRate}</b></span>
                  <span>रविवार दर: <b>₹${rates[0] || np.dailyRate}</b></span>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Submitted Requests -->
        ${requests.length > 0 ? `
          <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 space-y-2">
            <h4 class="font-bold text-xs text-slate-700 uppercase tracking-wider">आपके भेजे गए अनुरोध</h4>
            <div class="space-y-2">
              ${requests.map(r => `
                <div class="p-3 bg-amber-50/50 border border-amber-100 rounded-xl text-xs flex items-center justify-between">
                  <div>
                    <div class="font-bold text-slate-800">${r.paperName} (${r.copies} प्रति)</div>
                    <div class="text-[11px] text-slate-500">शुरू करने की तारीख: ${r.startDate}</div>
                  </div>
                  <span class="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">प्रक्रियाधीन (Pending)</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}
      </div>
    `;
  },

  openRequestModal(paperId) {
    const paper = CustStore.getNewspapers().find(p => p.id == paperId);
    if (!paper) return;
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().slice(0, 10);

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 cust-modal-overlay bg-black/60 backdrop-blur-sm">
        <div class="bg-white rounded-3xl max-w-sm w-full p-6 text-left space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 class="font-black text-slate-800 text-base">➕ नया अख़बार शुरू कराने का अनुरोध</h3>
            <button class="cust-modal-close text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
          </div>

          <p class="text-xs text-slate-500">चयनित अख़बार: <b class="text-slate-800 text-sm">${paper.name}</b></p>

          <form id="newPaperReqForm" class="space-y-3 text-sm">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">कब से शुरू करवाना है? *</label>
              <input type="date" id="reqStartDate" required value="${tomorrowStr}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">प्रतियों की संख्या (Copies)</label>
              <input type="number" min="1" max="10" id="reqCopies" value="1" required class="w-full px-3 py-2 border border-slate-200 rounded-xl font-bold">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">विशेष निर्देश (यदि कोई हो)</label>
              <input type="text" id="reqNotes" placeholder="उदा. मुख्य दरवाज़े के पास डालें" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
            </div>

            <div class="pt-2 flex items-center justify-end gap-2">
              <button type="button" class="cust-modal-close px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl">रद्द करें</button>
              <button type="submit" class="px-4 py-2 text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white rounded-xl">अनुरोध भेजें 🚀</button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('newPaperReqForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const startDate = document.getElementById('reqStartDate').value;
      const copies = parseInt(document.getElementById('reqCopies').value) || 1;
      const notes = document.getElementById('reqNotes').value.trim();

      const allReqs = CustStore.getRequests();
      allReqs.unshift({
        id: Date.now(),
        customerId: this.customer.id,
        customerName: this.customer.name,
        customerPhone: this.customer.phone,
        paperId: paper.id,
        paperName: paper.name,
        startDate,
        copies,
        notes,
        status: 'pending',
        date: new Date().toISOString().slice(0, 10)
      });
      CustStore.saveRequests(allReqs);

      this.closeModal();
      this.showToast("अनुरोध सफलतापूर्वक वितरक को भेज दिया गया!");
      this.renderTab('request');
    });
  },

  // ================= TAB 4: VACATION / STOP DELIVERY =================
  getVacationHTML() {
    const c = this.customer;
    const vacations = CustStore.getVacations().filter(v => v.customerId == c.id);
    const today = new Date().toISOString().slice(0, 10);

    return `
      <div class="space-y-4">
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100">
          <h3 class="font-bold text-slate-800 text-base">🏖️ छुट्टी / अस्थायी रोक की सूचना दें</h3>
          <p class="text-xs text-slate-500 mt-1">जब आप बाहर जा रहे हों, तो यहाँ तारीखें दर्ज करें। उन दिनों का अख़बार बंद रहेगा और <b>बिल में से पैसा अपने आप कट जाएगा</b>!</p>
        </div>

        <!-- Vacation Form -->
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100">
          <form id="custVacForm" class="space-y-3.5 text-sm">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">कब से बंद रखना है? *</label>
                <input type="date" id="custVacFrom" required value="${today}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
              </div>
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">कब तक बंद रखना है? *</label>
                <input type="date" id="custVacTo" required value="${today}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
              </div>
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">कारण</label>
              <input type="text" id="custVacReason" placeholder="उदा. गाँव जा रहे हैं / शादी में बाहर हैं" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
            </div>

            <button type="submit" class="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl shadow transition text-xs">
              🏖️ छुट्टी दर्ज करें (वितरक को सूचित करें)
            </button>
          </form>
        </div>

        <!-- Vacation Records -->
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 space-y-2">
          <h4 class="font-bold text-xs text-slate-700 uppercase tracking-wider">दर्ज की गई छुट्टियां</h4>
          ${vacations.length === 0 ? '<p class="text-xs text-slate-400">कोई छुट्टी दर्ज नहीं है।</p>' : `
            <div class="space-y-2">
              ${vacations.map(v => `
                <div class="p-3 bg-purple-50/50 border border-purple-100 rounded-xl text-xs flex items-center justify-between">
                  <div>
                    <div class="font-bold text-slate-800">${v.fromDate} से ${v.toDate}</div>
                    <div class="text-[11px] text-slate-500">${v.reason || 'निजी कार्य'}</div>
                  </div>
                  <span class="text-[10px] font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-md">सत्यापित</span>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;
  },

  // ================= TAB 5: HELP & CONTACT =================
  getHelpHTML() {
    const agency = CustStore.getAgency();
    const cleanPhone = agency.phone.replace(/[^0-9]/g, '');
    const phoneWithCode = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;

    return `
      <div class="space-y-4">
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 text-center space-y-3">
          <div class="w-16 h-16 bg-blue-50 text-blue-700 rounded-2xl flex items-center justify-center text-3xl mx-auto">
            🏢
          </div>
          <div>
            <h3 class="font-black text-slate-800 text-lg">${agency.name}</h3>
            <p class="text-xs text-slate-500">वितरक: <b>${agency.owner}</b></p>
            <p class="text-xs text-slate-500 mt-1">📍 ${agency.address}</p>
          </div>

          <div class="grid grid-cols-2 gap-3 pt-2">
            <a href="tel:${cleanPhone}" class="p-3 bg-blue-600 text-white rounded-2xl font-bold text-xs shadow flex items-center justify-center gap-1.5">
              <span>📞 कॉल करें</span>
            </a>
            <a href="https://wa.me/${phoneWithCode}" target="_blank" class="p-3 bg-emerald-600 text-white rounded-2xl font-bold text-xs shadow flex items-center justify-center gap-1.5">
              <span>💬 WhatsApp</span>
            </a>
          </div>
        </div>

        <!-- FAQ Box -->
        <div class="bg-white rounded-3xl p-5 cust-card border border-slate-100 space-y-3 text-xs">
          <h4 class="font-bold text-slate-800 text-sm">❓ अक्सर पूछे जाने वाले सवाल (FAQ)</h4>

          <div class="space-y-2 text-slate-600">
            <div class="p-3 bg-slate-50 rounded-xl space-y-1">
              <p class="font-bold text-slate-800">1. छुट्टी लेने पर बिल कैसे कटता है?</p>
              <p class="text-slate-500">जब आप 'छुट्टी/रोक' में तारीखें डालते हैं, तो उन दिनों का शुल्क आपके मासिक बिल में से अपने आप घट जाता है।</p>
            </div>

            <div class="p-3 bg-slate-50 rounded-xl space-y-1">
              <p class="font-bold text-slate-800">2. ऑनलाइन भुगतान कैसे करें?</p>
              <p class="text-slate-500">'मेरा खाता' टैब में 'ऑनलाइन भुगतान करें' दबाकर आप PhonePe, Google Pay या Paytm से सीधे वितरक के खाते में भुगतान कर सकते हैं।</p>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // ================= TAB: LIVE CHAT WITH DISTRIBUTOR =================
  getChatHTML() {
    const c = this.customer;
    const agency = CustStore.getAgency();
    const chats = CustStore.getChats();
    const myChats = chats.filter(m => m.customerId == c.id);

    // Mark distributor messages as read by customer
    let updated = false;
    chats.forEach(m => {
      if (m.customerId == c.id && m.sender === 'distributor' && !m.readByCustomer) {
        m.readByCustomer = true;
        updated = true;
      }
    });
    if (updated) {
      CustStore.saveChats(chats);
      this.updateChatBadges();
    }

    const cleanPhone = agency.phone.replace(/[^0-9]/g, '');

    return `
      <div class="space-y-3 pb-2">
        <!-- Chat Header Card -->
        <div class="bg-white rounded-3xl p-4 cust-card border border-slate-100 flex items-center justify-between gap-3 shadow-sm">
          <div class="flex items-center gap-3">
            <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 text-white flex items-center justify-center text-xl shadow-inner font-bold">
              📰
            </div>
            <div>
              <h3 class="font-black text-slate-800 text-sm leading-tight">${agency.name}</h3>
              <p class="text-[11px] text-slate-500">वितरक: <b>${agency.owner}</b></p>
              <div class="flex items-center gap-1.5 mt-0.5">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="text-[10px] font-bold text-emerald-600">ऑनलाइन (सक्रिय)</span>
              </div>
            </div>
          </div>
          <a href="tel:${cleanPhone}" class="p-2.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-2xl transition flex items-center gap-1 text-xs font-bold" title="सीधे फोन करें">
            <span>📞 कॉल</span>
          </a>
        </div>

        <!-- Quick Question Chips -->
        <div>
          <p class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 px-1">⚡ तुरंत पूछने के लिए टैप करें:</p>
          <div class="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button type="button" onclick="CustApp.openFeedbackModal()" class="whitespace-nowrap px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl transition text-[11px] flex items-center gap-1 flex-shrink-0 shadow-sm">
              <span>⭐</span>
              <span>फीडबैक / रेटिंग दें</span>
            </button>
            <button type="button" onclick="CustApp.sendQuickMessage('आज का अख़बार अभी तक नहीं मिला है, कृपया चेक करें।')" class="whitespace-nowrap px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-slate-700 font-medium hover:bg-sky-50 hover:border-sky-300 transition text-[11px] flex-shrink-0 shadow-sm">
              🗞️ आज का अख़बार नहीं आया
            </button>
            <button type="button" onclick="CustApp.sendQuickMessage('कृपया मेरे चालू महीने का बिल व रसीद भेजें।')" class="whitespace-nowrap px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-slate-700 font-medium hover:bg-sky-50 hover:border-sky-300 transition text-[11px] flex-shrink-0 shadow-sm">
              🧾 बिल / रसीद चाहिए
            </button>
            <button type="button" onclick="CustApp.sendQuickMessage('कल सुबह मुझे 1 अतिरिक्त अख़बार चाहिए।')" class="whitespace-nowrap px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-slate-700 font-medium hover:bg-sky-50 hover:border-sky-300 transition text-[11px] flex-shrink-0 shadow-sm">
              ➕ कल 1 एक्स्ट्रा कॉपी देना
            </button>
            <button type="button" onclick="CustApp.sendQuickMessage('मैंने ₹' + (${parseFloat(c.currentDue) || 0}) + ' का भुगतान PhonePe/UPI से कर दिया है।')" class="whitespace-nowrap px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-slate-700 font-medium hover:bg-sky-50 hover:border-sky-300 transition text-[11px] flex-shrink-0 shadow-sm">
              💰 पेमेंट कर दिया है
            </button>
          </div>
        </div>

        <!-- Messages Box -->
        <div id="custChatMessagesBox" class="bg-slate-100/70 border border-slate-200/80 rounded-3xl p-4 h-[370px] overflow-y-auto space-y-3 flex flex-col">
          ${myChats.length === 0 ? `
            <div class="my-auto text-center space-y-2 py-8">
              <div class="text-4xl">💬</div>
              <p class="font-bold text-slate-700 text-sm">अभी कोई बातचीत नहीं हुई है</p>
              <p class="text-xs text-slate-400 max-w-xs mx-auto">नीचे संदेश लिखकर भेजें या ऊपर दिए गए विकल्पों पर क्लिक करें। वितरक को तुरंत संदेश मिल जाएगा।</p>
            </div>
          ` : myChats.map(m => {
            const isMe = m.sender === 'customer';
            return `
              <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1">
                <span class="text-[10px] text-slate-400 font-semibold px-1">
                  ${isMe ? 'आप' : '🏢 ' + agency.owner + ' (एजेंसी)'}
                </span>
                <div class="max-w-[85%] p-3.5 rounded-2xl shadow-sm text-xs break-words ${
                  isMe 
                    ? 'bg-sky-600 text-white rounded-tr-none' 
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none font-medium'
                }">
                  <p class="leading-relaxed whitespace-pre-wrap">${this.escapeHTML(m.text)}</p>
                </div>
                <div class="flex items-center gap-1 text-[10px] text-slate-400 px-1">
                  <span>${m.timeStr || ''}</span>
                  ${isMe ? '<span class="text-sky-600 font-bold">✓✓</span>' : ''}
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Input Box -->
        <form id="custSendMessageForm" class="flex items-center gap-2">
          <input 
            type="text" 
            id="custChatInput" 
            placeholder="यहाँ अपना सवाल या संदेश लिखें..." 
            autocomplete="off" 
            required
            class="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-sky-500 shadow-sm"
          >
          <button 
            type="submit" 
            class="px-4 py-3 bg-sky-600 hover:bg-sky-700 active:scale-95 text-white font-bold rounded-2xl shadow-md transition flex items-center justify-center gap-1.5 text-xs sm:text-sm flex-shrink-0"
          >
            <span>भेजें</span>
            <span>🚀</span>
          </button>
        </form>
      </div>
    `;
  },

  attachChatEvents() {
    const form = document.getElementById('custSendMessageForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('custChatInput');
      const text = input ? input.value.trim() : '';
      if (!text) return;
      this.sendChatMessage(text);
      if (input) input.value = '';
    });

    this.scrollChatToBottom();
  },

  sendQuickMessage(text) {
    this.sendChatMessage(text);
  },

  sendChatMessage(text) {
    if (!this.customer) return;
    const chats = CustStore.getChats();
    const now = new Date();
    const timeStr = now.toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' });

    const newMsg = {
      id: 'msg_' + Date.now(),
      customerId: this.customer.id,
      customerName: this.customer.name,
      customerPhone: this.customer.phone,
      sender: 'customer',
      text: text,
      timestamp: now.toISOString(),
      timeStr: timeStr,
      readByDistributor: false,
      readByCustomer: true
    };

    chats.push(newMsg);
    CustStore.saveChats(chats);

    this.renderTab('chat');
    this.attachChatEvents();
    this.updateChatBadges();
    this.showToast("संदेश भेज दिया गया! 🚀");
  },

  refreshChatIfOpen() {
    const box = document.getElementById('custChatMessagesBox');
    if (!box || !this.customer) return;
    const isAtBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 50;

    const chats = CustStore.getChats();
    const myChats = chats.filter(m => m.customerId == this.customer.id);
    const agency = CustStore.getAgency();

    // Mark as read
    let updated = false;
    chats.forEach(m => {
      if (m.customerId == this.customer.id && m.sender === 'distributor' && !m.readByCustomer) {
        m.readByCustomer = true;
        updated = true;
      }
    });
    if (updated) {
      CustStore.saveChats(chats);
    }

    if (myChats.length === 0) {
      box.innerHTML = `
        <div class="my-auto text-center space-y-2 py-8">
          <div class="text-4xl">💬</div>
          <p class="font-bold text-slate-700 text-sm">अभी कोई बातचीत नहीं हुई है</p>
          <p class="text-xs text-slate-400 max-w-xs mx-auto">नीचे संदेश लिखकर भेजें या ऊपर दिए गए विकल्पों पर क्लिक करें। वितरक को तुरंत संदेश मिल जाएगा।</p>
        </div>
      `;
    } else {
      box.innerHTML = myChats.map(m => {
        const isMe = m.sender === 'customer';
        return `
          <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1">
            <span class="text-[10px] text-slate-400 font-semibold px-1">
              ${isMe ? 'आप' : '🏢 ' + agency.owner + ' (एजेंसी)'}
            </span>
            <div class="max-w-[85%] p-3.5 rounded-2xl shadow-sm text-xs break-words ${
              isMe 
                ? 'bg-sky-600 text-white rounded-tr-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none font-medium'
            }">
              <p class="leading-relaxed whitespace-pre-wrap">${this.escapeHTML(m.text)}</p>
            </div>
            <div class="flex items-center gap-1 text-[10px] text-slate-400 px-1">
              <span>${m.timeStr || ''}</span>
              ${isMe ? '<span class="text-sky-600 font-bold">✓✓</span>' : ''}
            </div>
          </div>
        `;
      }).join('');
    }

    if (isAtBottom) {
      this.scrollChatToBottom();
    }
  },

  scrollChatToBottom() {
    const box = document.getElementById('custChatMessagesBox');
    if (box) {
      box.scrollTop = box.scrollHeight;
    }
  },

  updateChatBadges() {
    if (!this.customer) return;
    const chats = CustStore.getChats();
    const unreadFromDistributor = chats.filter(m => m.customerId == this.customer.id && m.sender === 'distributor' && !m.readByCustomer).length;

    const navBadge = document.getElementById('custChatUnreadBadge');
    if (navBadge) {
      navBadge.classList.toggle('hidden', unreadFromDistributor === 0);
    }
    const headerBadge = document.getElementById('custHeaderChatBadge');
    if (headerBadge) {
      headerBadge.classList.toggle('hidden', unreadFromDistributor === 0);
    }
  },

  escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  openFeedbackModal() {
    const c = this.customer;
    if (!c) return;

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 cust-modal-overlay bg-black/60 backdrop-blur-sm">
        <div class="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 class="font-black text-slate-800 text-base">⭐ एजेंसी को फीडबैक व रेटिंग दें</h3>
            <button class="cust-modal-close text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
          </div>

          <p class="text-xs text-slate-500 text-left">
            आपकी राय से हमें सेवा बेहतर बनाने में मदद मिलती है। कृपया अपनी रेटिंग चुनें:
          </p>

          <!-- 5 Stars Selector -->
          <div class="flex items-center justify-center gap-2 py-1" id="starRatingContainer">
            <button type="button" onclick="CustApp.selectRating(1)" class="star-btn text-3xl transition hover:scale-125 focus:outline-none" data-star="1">⭐</button>
            <button type="button" onclick="CustApp.selectRating(2)" class="star-btn text-3xl transition hover:scale-125 focus:outline-none" data-star="2">⭐</button>
            <button type="button" onclick="CustApp.selectRating(3)" class="star-btn text-3xl transition hover:scale-125 focus:outline-none" data-star="3">⭐</button>
            <button type="button" onclick="CustApp.selectRating(4)" class="star-btn text-3xl transition hover:scale-125 focus:outline-none" data-star="4">⭐</button>
            <button type="button" onclick="CustApp.selectRating(5)" class="star-btn text-3xl transition hover:scale-125 focus:outline-none" data-star="5">⭐</button>
          </div>
          <div id="starRatingText" class="text-xs font-bold text-amber-600">5 स्टार - बहुत बढ़िया सेवा!</div>

          <form id="custFeedbackForm" class="space-y-3 text-left">
            <input type="hidden" id="feedbackRatingValue" value="5">

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">फीडबैक का विषय चुनें:</label>
              <select id="feedbackCategory" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500">
                <option value="समय पर वितरण (On-time Delivery)">🚀 समय पर अख़बार मिला (On-Time)</option>
                <option value="हॉकर का व्यवहार (Hawker Behavior)">🚴‍♂️ हॉकर की सेवा अच्छी है</option>
                <option value="बिल व भुगतान (Billing & Payments)">🧾 बिल व भुगतान में कोई समस्या</option>
                <option value="अख़बार फटा/खराब (Damaged Newspaper)">⚠️ अख़बार फटा या खराब मिला</option>
                <option value="सामान्य सुझाव (General Suggestion)">💡 अन्य सुझाव या विचार</option>
              </select>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-700 mb-1">अपनी बात / अनुभव लिखें:</label>
              <textarea id="feedbackComment" rows="3" required placeholder="जैसे: रोज़ाना सुबह 6:30 बजे अख़बार मिल जाता है, बहुत अच्छी सर्विस है..." class="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea>
            </div>

            <button type="submit" class="w-full py-3 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-amber-500/30 transition text-sm flex items-center justify-center gap-1.5">
              <span>फीडबैक सबमिट करें</span>
              <span>⭐</span>
            </button>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    const form = document.getElementById('custFeedbackForm');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const rating = parseInt(document.getElementById('feedbackRatingValue').value) || 5;
        const category = document.getElementById('feedbackCategory').value;
        const comment = document.getElementById('feedbackComment').value.trim();
        this.submitFeedback(rating, category, comment);
      });
    }
  },

  selectRating(stars) {
    const valInput = document.getElementById('feedbackRatingValue');
    if (valInput) valInput.value = stars;
    const texts = {
      1: "1 स्टार - बहुत असंतोषजनक",
      2: "2 स्टार - सुधार की ज़रूरत है",
      3: "3 स्टार - ठीक-ठाक सेवा",
      4: "4 स्टार - अच्छी सेवा",
      5: "5 स्टार - बहुत बढ़िया सेवा!"
    };
    const textEl = document.getElementById('starRatingText');
    if (textEl) textEl.textContent = texts[stars] || `${stars} स्टार`;

    document.querySelectorAll('.star-btn').forEach(btn => {
      const s = parseInt(btn.getAttribute('data-star'));
      btn.style.opacity = s <= stars ? '1' : '0.25';
    });
  },

  submitFeedback(rating, category, comment) {
    if (!this.customer) return;

    const feedbackText = `⭐ [ग्राहक फीडबैक - ${rating}/5 स्टार]: "${comment}" (विषय: ${category})`;

    // 1. Save to np_feedbacks
    const feedbacks = CustStore.get('feedbacks', []);
    const newFb = {
      id: 'fb_' + Date.now(),
      customerId: this.customer.id,
      customerName: this.customer.name,
      customerPhone: this.customer.phone,
      rating: rating,
      category: category,
      comment: comment,
      date: new Date().toISOString(),
      dateStr: new Date().toLocaleDateString('hi-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
    };
    feedbacks.push(newFb);
    CustStore.save('feedbacks', feedbacks);

    // 2. Also send as message in chat so distributor gets immediate notification
    this.sendChatMessage(feedbackText);

    this.closeModal();
    this.showToast("आपका फीडबैक वितरक तक पहुँच गया है! धन्यवाद ⭐");
  }
};

document.addEventListener('DOMContentLoaded', () => {
  CustApp.init();

  // Handle vacation form submit dynamically
  document.addEventListener('submit', (e) => {
    if (e.target && e.target.id === 'custVacForm') {
      e.preventDefault();
      const fromDate = document.getElementById('custVacFrom').value;
      const toDate = document.getElementById('custVacTo').value;
      const reason = document.getElementById('custVacReason').value.trim();

      if (fromDate > toDate) {
        alert("शुरुआत की तारीख समाप्ति की तारीख से पहले होनी चाहिए!");
        return;
      }

      const allVac = CustStore.getVacations();
      allVac.push({
        id: Date.now(),
        customerId: CustApp.customer.id,
        fromDate,
        toDate,
        reason: reason || "ग्राहक पोर्टल से दर्ज",
        status: 'active'
      });
      CustStore.saveVacations(allVac);

      CustApp.showToast("छुट्टी सफलतापूर्वक दर्ज की गई!");
      CustApp.renderTab('vacation');
    }
  });
});
