/**
 * अख़बार वितरक एवं हिसाब-किताब प्रबंधन प्रणाली (Newspaper Distributor Management System)
 * Feature: Full Day-Wise Weekly Rates (सप्ताह के 7 दिनों की अलग-अलग दरों का प्रबंधन)
 */

const DAYS_NAMES_HI = ["रविवार (Sun)", "सोमवार (Mon)", "मंगलवार (Tue)", "बुधवार (Wed)", "गुरुवार (Thu)", "शुक्रवार (Fri)", "शनिवार (Sat)"];
const DAYS_SHORT_HI = ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"];

// Initial Sample Data in Hindi
const DEFAULT_AGENCY = {
  name: "श्री गणेश न्यूज़पेपर एजेंसी",
  owner: "avinash raj",
  phone: "9876543210",
  address: "दुकान नं. 12, मुख्य बस स्टैंड",
  upiId: "araj00356-2@okaxis",
  tagline: "विश्वसनीय व समय पर दैनिक समाचार पत्र वितरण सेवा"
};

const DEFAULT_NEWSPAPERS = [
  {
    id: 1,
    name: "दैनिक भास्कर",
    language: "हिन्दी",
    dailyRate: 5.0,
    pressCost: 3.5,
    ratesByDay: { 0: 7.0, 1: 5.0, 2: 5.0, 3: 6.0, 4: 5.0, 5: 5.0, 6: 6.0 } // बुध व शनि ₹6 (विशेषांक), रवि ₹7
  },
  {
    id: 2,
    name: "राजस्थान पत्रिका",
    language: "हिन्दी",
    dailyRate: 5.0,
    pressCost: 3.5,
    ratesByDay: { 0: 6.0, 1: 5.0, 2: 5.0, 3: 5.5, 4: 5.0, 5: 5.0, 6: 5.5 }
  },
  {
    id: 3,
    name: "दैनिक जागरण",
    language: "हिन्दी",
    dailyRate: 5.0,
    pressCost: 3.5,
    ratesByDay: { 0: 6.0, 1: 5.0, 2: 5.0, 3: 5.0, 4: 5.0, 5: 5.0, 6: 5.0 }
  },
  {
    id: 4,
    name: "The Times of India",
    language: "English",
    dailyRate: 8.0,
    pressCost: 6.0,
    ratesByDay: { 0: 10.0, 1: 8.0, 2: 8.0, 3: 8.0, 4: 8.0, 5: 8.0, 6: 9.0 }
  },
  {
    id: 5,
    name: "हिन्दुस्तान",
    language: "हिन्दी",
    dailyRate: 4.5,
    pressCost: 3.2,
    ratesByDay: { 0: 5.5, 1: 4.5, 2: 4.5, 3: 5.0, 4: 4.5, 5: 4.5, 6: 4.5 }
  }
];

const DEFAULT_LINES = [
  { id: 1, name: "लाइन 1 - मुख्य बाज़ार व स्टेशन रोड", hawkerName: "सुरेश कुमार", hawkerPhone: "9811122334", commissionPerCopy: 1.2 },
  { id: 2, name: "लाइन 2 - सिविल लाइन्स व कलेक्ट्रेट", hawkerName: "मनोज वर्मा", hawkerPhone: "9822233445", commissionPerCopy: 1.2 },
  { id: 3, name: "लाइन 3 - शास्त्री नगर व न्यू कॉलोनी", hawkerName: "विकास सैनी", hawkerPhone: "9833344556", commissionPerCopy: 1.2 }
];

const DEFAULT_CUSTOMERS = [
  {
    id: 1,
    name: "डॉ. सतीश अग्रवाल",
    phone: "9829011111",
    address: "मकान नं. 45, सिविल लाइन्स",
    lineId: 2,
    papers: [
      { paperId: 1, copies: 1 },
      { paperId: 4, copies: 1 }
    ],
    status: "active",
    openingDue: 150,
    currentDue: 550,
    startDate: "2026-01-01"
  },
  {
    id: 2,
    name: "रामगोपाल जी किराना स्टोर",
    phone: "9829022222",
    address: "दुकान 18, मुख्य बाज़ार",
    lineId: 1,
    papers: [
      { paperId: 1, copies: 1 },
      { paperId: 2, copies: 1 }
    ],
    status: "active",
    openingDue: 0,
    currentDue: 310,
    startDate: "2026-02-15"
  },
  {
    id: 3,
    name: "एडवोकेट महेन्द्र सिंह",
    phone: "9829033333",
    address: "B-12, कलेक्ट्रेट रोड",
    lineId: 2,
    papers: [
      { paperId: 3, copies: 1 },
      { paperId: 4, copies: 1 }
    ],
    status: "active",
    openingDue: 0,
    currentDue: 0,
    startDate: "2026-03-01"
  },
  {
    id: 4,
    name: "सुनीता शर्मा (शिक्षिका)",
    phone: "9829044444",
    address: "मकान 102, शास्त्री नगर",
    lineId: 3,
    papers: [
      { paperId: 1, copies: 1 }
    ],
    status: "active",
    openingDue: 50,
    currentDue: 205,
    startDate: "2026-04-10"
  },
  {
    id: 5,
    name: "विजय इलेक्ट्रॉनिक्स",
    phone: "9829055555",
    address: "स्टेशन रोड, तिराहा",
    lineId: 1,
    papers: [
      { paperId: 2, copies: 2 }
    ],
    status: "active",
    openingDue: 0,
    currentDue: 310,
    startDate: "2026-05-01"
  }
];

const DEFAULT_VACATIONS = [
  {
    id: 1,
    customerId: 3,
    fromDate: "2026-10-05",
    toDate: "2026-10-09",
    reason: "कोर्ट की छुट्टियों में बाहर गए हैं",
    status: "completed"
  }
];

const DEFAULT_PAYMENTS = [
  {
    id: 1,
    receiptNo: "REC-1001",
    customerId: 3,
    date: "2026-10-01",
    amount: 400,
    mode: "UPI (PhonePe)",
    note: "सितम्बर माह का बिल भुगतान"
  },
  {
    id: 2,
    receiptNo: "REC-1002",
    customerId: 2,
    date: "2026-10-03",
    amount: 300,
    mode: "नगद (Cash)",
    note: "हॉकर सुरेश को दिया"
  }
];

const DEFAULT_CHATS = [
  {
    id: "msg_1",
    customerId: 1,
    customerName: "डॉ. सतीश अग्रवाल",
    customerPhone: "9829011111",
    sender: "customer",
    text: "नमस्ते, कल सुबह मुझे दैनिक भास्कर की 1 अतिरिक्त कॉपी चाहिए।",
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    timeStr: "सुबह 10:30",
    readByDistributor: false,
    readByCustomer: true
  },
  {
    id: "msg_2",
    customerId: 1,
    customerName: "डॉ. सतीश अग्रवाल",
    customerPhone: "9829011111",
    sender: "distributor",
    text: "नमस्ते डॉक्टर साहब! जी बिल्कुल, हॉकर को बोल दिया है, कल सुबह 2 प्रतियां मिल जाएंगी।",
    timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
    timeStr: "सुबह 11:00",
    readByDistributor: true,
    readByCustomer: true
  },
  {
    id: "msg_3",
    customerId: 2,
    customerName: "रामगोपाल जी किराना स्टोर",
    customerPhone: "9829022222",
    sender: "customer",
    text: "भाई साहब, मैंने ₹310 PhonePe कर दिए हैं, कृपया बिल में चेक कर लें।",
    timestamp: new Date(Date.now() - 3600000 * 1).toISOString(),
    timeStr: "दोपहर 01:15",
    readByDistributor: false,
    readByCustomer: true
  },
  {
    id: "msg_4",
    customerId: 3,
    customerName: "शर्मा जी (वकील साहब)",
    customerPhone: "9829033333",
    sender: "customer",
    text: "⭐ [ग्राहक फीडबैक - 5/5 स्टार]: \"रोज़ सुबह 6:15 बजे बिना नागा दैनिक जागरण मिल जाता है। हॉकर विकास का काम बहुत बढ़िया है!\" (विषय: समय पर वितरण)",
    timestamp: new Date(Date.now() - 3600000 * 0.5).toISOString(),
    timeStr: "दोपहर 03:30",
    readByDistributor: false,
    readByCustomer: true
  }
];

const DEFAULT_FEEDBACKS = [
  {
    id: "fb_1",
    customerId: 3,
    customerName: "शर्मा जी (वकील साहब)",
    customerPhone: "9829033333",
    rating: 5,
    category: "समय पर वितरण (On-time Delivery)",
    comment: "रोज़ सुबह 6:15 बजे बिना नागा दैनिक जागरण मिल जाता है। हॉकर विकास का काम बहुत बढ़िया है!",
    date: new Date(Date.now() - 3600000 * 0.5).toISOString(),
    dateStr: "आज, दोपहर 03:30"
  },
  {
    id: "fb_2",
    customerId: 1,
    customerName: "डॉ. सतीश अग्रवाल",
    customerPhone: "9829011111",
    rating: 5,
    category: "हॉकर का व्यवहार (Hawker Behavior)",
    comment: "अख़बार हमेशा साफ़-सुथरा और बालकनी में समय पर मिलता है।",
    date: new Date(Date.now() - 86400000).toISOString(),
    dateStr: "कल"
  }
];

// App State Manager
class NewspaperStore {
  constructor() {
    this.init();
  }

  init() {
    this.agency = this.get('agency', DEFAULT_AGENCY);
    if (!this.agency.upiId || this.agency.upiId === 'rajeshagency@upi' || this.agency.upiId === 'agency@upi') {
      this.agency.upiId = 'araj00356-2@okaxis';
      this.save('agency', this.agency);
    }
    let papers = this.get('newspapers', DEFAULT_NEWSPAPERS);
    
    // Ensure day-wise rates are present for all papers
    papers = papers.map(p => {
      if (!p.ratesByDay) {
        const dRate = p.dailyRate || 5;
        const sRate = p.sundayRate || dRate;
        p.ratesByDay = { 0: sRate, 1: dRate, 2: dRate, 3: dRate, 4: dRate, 5: dRate, 6: dRate };
      }
      return p;
    });

    this.newspapers = papers;
    this.lines = this.get('lines', DEFAULT_LINES);
    this.customers = this.get('customers', DEFAULT_CUSTOMERS);
    this.vacations = this.get('vacations', DEFAULT_VACATIONS);
    this.payments = this.get('payments', DEFAULT_PAYMENTS);
    this.billAdjustments = this.get('billAdjustments', {});
    this.chats = this.get('chats', DEFAULT_CHATS);
    this.feedbacks = this.get('feedbacks', DEFAULT_FEEDBACKS);
  }

  get(key, fallback) {
    const data = localStorage.getItem('np_' + key);
    if (!data) {
      localStorage.setItem('np_' + key, JSON.stringify(fallback));
      return fallback;
    }
    try {
      return JSON.parse(data);
    } catch (e) {
      return fallback;
    }
  }

  save(key, val) {
    this[key] = val;
    localStorage.setItem('np_' + key, JSON.stringify(val));
  }

  resetAll() {
    localStorage.removeItem('np_agency');
    localStorage.removeItem('np_newspapers');
    localStorage.removeItem('np_lines');
    localStorage.removeItem('np_customers');
    localStorage.removeItem('np_vacations');
    localStorage.removeItem('np_payments');
    localStorage.removeItem('np_billAdjustments');
    localStorage.removeItem('np_chats');
    localStorage.removeItem('np_feedbacks');
    this.init();
  }
}

const store = new NewspaperStore();

// UI Application Logic
const App = {
  currentTab: 'dashboard',
  selectedMonth: new Date().toISOString().slice(0, 7), // YYYY-MM
  activeChatCustomerId: null,
  chatSearchQuery: '',
  soundEnabled: true,
  lastKnownMessageId: null,

  init() {
    this.bindEvents();
    this.renderHeader();

    // Remember latest message ID to avoid alerting on existing data at startup
    const initChats = store.get('chats', DEFAULT_CHATS);
    if (initChats.length > 0) {
      this.lastKnownMessageId = initChats[initChats.length - 1].id;
    }

    this.updateChatBadges();
    this.renderTab(this.currentTab);

    // Prompt for desktop notifications on first interaction
    document.addEventListener('click', () => {
      this.requestNotificationPermissionOnce();
    }, { once: true });

    // Live sync when customer sends a message or feedback
    window.addEventListener('storage', (e) => {
      if (e.key === 'np_chats' || e.key === 'np_feedbacks') {
        this.checkForIncomingMessages();
      }
    });

    setInterval(() => {
      this.checkForIncomingMessages();
    }, 1500);
  },

  bindEvents() {
    document.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = e.currentTarget.getAttribute('data-tab');
        this.switchTab(tab);
      });
    });

    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-overlay') || e.target.classList.contains('modal-close-btn')) {
        this.closeAllModals();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeAllModals();
    });
  },

  renderHeader() {
    const agencyEl = document.getElementById('headerAgencyName');
    if (agencyEl) agencyEl.textContent = store.agency.name;
    const ownerEl = document.getElementById('headerAgencyOwner');
    if (ownerEl) ownerEl.textContent = `वितरक: ${store.agency.owner} (${store.agency.phone})`;
  },

  switchTab(tabName) {
    this.currentTab = tabName;

    document.querySelectorAll('[data-tab]').forEach(btn => {
      const match = btn.getAttribute('data-tab') === tabName;
      btn.classList.toggle('bg-blue-800', match && btn.classList.contains('nav-link-desktop'));
      btn.classList.toggle('text-white', match);
      btn.classList.toggle('text-blue-100', !match && btn.classList.contains('nav-link-desktop'));
      btn.classList.toggle('text-blue-600', match && btn.classList.contains('nav-link-mobile'));
      btn.classList.toggle('text-gray-500', !match && btn.classList.contains('nav-link-mobile'));
    });

    this.renderTab(tabName);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  openCustomerChat(custId) {
    this.activeChatCustomerId = custId;
    this.switchTab('chats');
  },

  renderTab(tabName) {
    const container = document.getElementById('mainContentArea');
    if (!container) return;

    switch (tabName) {
      case 'dashboard':
        container.innerHTML = this.getDashboardHTML();
        break;
      case 'customers':
        container.innerHTML = this.getCustomersHTML();
        this.attachCustomerEvents();
        break;
      case 'lines':
        container.innerHTML = this.getLinesHTML();
        break;
      case 'newspapers':
        container.innerHTML = this.getNewspapersHTML();
        break;
      case 'billing':
        container.innerHTML = this.getBillingHTML();
        this.attachBillingEvents();
        break;
      case 'payments':
        container.innerHTML = this.getPaymentsHTML();
        break;
      case 'vacations':
        container.innerHTML = this.getVacationsHTML();
        break;
      case 'requests':
        container.innerHTML = this.getRequestsHTML();
        break;
      case 'chats':
        container.innerHTML = this.getChatsHTML();
        this.attachChatEvents();
        break;
      case 'settings':
        container.innerHTML = this.getSettingsHTML();
        this.attachSettingsEvents();
        break;
      default:
        container.innerHTML = `<div class="p-4 text-center">पृष्ठ लोड हो रहा है...</div>`;
    }
  },

  showToast(message, type = 'success') {
    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-emerald-600' : type === 'error' ? 'bg-red-600' : 'bg-blue-600';
    toast.className = `fixed top-5 right-5 z-50 flex items-center gap-2 px-4 py-3 text-white rounded-xl shadow-2xl toast-animate ${bgClass}`;
    toast.innerHTML = `
      <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        ${type === 'success' 
          ? '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>'
          : '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>'}
      </svg>
      <span class="font-medium text-sm sm:text-base">${message}</span>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  },

  closeAllModals() {
    const modalContainer = document.getElementById('modalContainer');
    if (modalContainer) {
      modalContainer.classList.add('hidden');
      modalContainer.innerHTML = '';
    }
  },

  openModal(html) {
    const modalContainer = document.getElementById('modalContainer');
    if (!modalContainer) return;
    modalContainer.innerHTML = html;
    modalContainer.classList.remove('hidden');
  },

  getTodayDeliveryStats() {
    const today = new Date().toISOString().slice(0, 10);
    const dayOfWeek = new Date().getDay();
    const pausedCustIds = new Set(
      store.vacations
        .filter(v => v.fromDate <= today && v.toDate >= today)
        .map(v => v.customerId)
    );

    const paperCounts = {};
    store.newspapers.forEach(p => paperCounts[p.id] = 0);

    let activeDeliveries = 0;
    store.customers.forEach(c => {
      if (c.status === 'active' && !pausedCustIds.has(c.id)) {
        activeDeliveries++;
        (c.papers || []).forEach(cp => {
          paperCounts[cp.paperId] = (paperCounts[cp.paperId] || 0) + (cp.copies || 1);
        });
      }
    });

    return { activeDeliveries, pausedCount: pausedCustIds.size, paperCounts, dayOfWeek };
  },

  // ================= DASHBOARD =================
  getDashboardHTML() {
    const today = new Date().toLocaleDateString('hi-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const stats = this.getTodayDeliveryStats();
    const totalDue = store.customers.reduce((acc, c) => acc + (parseFloat(c.currentDue) || 0), 0);
    const currentMonthPrefix = new Date().toISOString().slice(0, 7);
    const thisMonthCollection = store.payments
      .filter(p => (p.date || '').startsWith(currentMonthPrefix))
      .reduce((acc, p) => acc + (parseFloat(p.amount) || 0), 0);
    const unreadChatsCount = (store.chats || []).filter(m => m.sender === 'customer' && !m.readByDistributor).length;

    return `
      <div class="space-y-6">
        <div class="bg-gradient-to-r from-blue-900 to-indigo-800 text-white rounded-2xl p-5 sm:p-7 shadow-lg relative overflow-hidden">
          <div class="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div class="inline-flex items-center gap-2 bg-blue-700/50 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold text-blue-200 mb-2">
                <span>📅 ${today} (आज का दिन: ${DAYS_NAMES_HI[stats.dayOfWeek]})</span>
              </div>
              <div class="flex items-center gap-2">
                <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight">${store.agency.name}</h2>
                <button onclick="App.openEditAgencyModal()" class="text-blue-200 hover:text-white p-1 rounded-lg text-sm bg-blue-800/60" title="एजेंसी विवरण एडिट करें">✏️</button>
              </div>
              <p class="text-blue-200 text-sm mt-1">${store.agency.tagline}</p>
            </div>
            <div class="flex items-center gap-2 flex-wrap">
              <button onclick="App.openAddCustomerModal()" class="touch-btn bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-bold px-4 py-2.5 rounded-xl shadow-md transition flex items-center gap-2 text-sm">
                <span>➕ नया ग्राहक</span>
              </button>
              <button onclick="App.openRecordPaymentModal()" class="touch-btn bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-bold px-4 py-2.5 rounded-xl shadow-md transition flex items-center gap-2 text-sm">
                <span>💰 भुगतान लें</span>
              </button>
            </div>
          </div>
        </div>

        <!-- 4 Metric Cards -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
          <div onclick="App.switchTab('customers')" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow cursor-pointer hover:border-blue-400 transition flex flex-col justify-between">
            <div class="flex items-center justify-between text-slate-500 mb-2">
              <span class="text-xs sm:text-sm font-semibold">कुल ग्राहक</span>
              <span class="p-2 bg-blue-50 text-blue-600 rounded-xl text-lg">👥</span>
            </div>
            <div>
              <div class="text-2xl sm:text-3xl font-black text-slate-800">${store.customers.length}</div>
              <p class="text-xs text-emerald-600 font-medium mt-1">क्लिक करके देखें/एडिट करें →</p>
            </div>
          </div>

          <div onclick="App.switchTab('newspapers')" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow cursor-pointer hover:border-indigo-400 transition flex flex-col justify-between">
            <div class="flex items-center justify-between text-slate-500 mb-2">
              <span class="text-xs sm:text-sm font-semibold">आज के अख़बार</span>
              <span class="p-2 bg-indigo-50 text-indigo-600 rounded-xl text-lg">📰</span>
            </div>
            <div>
              <div class="text-2xl sm:text-3xl font-black text-indigo-900">
                ${Object.values(stats.paperCounts).reduce((a, b) => a + b, 0)}
              </div>
              <p class="text-xs text-slate-500 font-medium mt-1">सप्ताह की दरें एडिट करें →</p>
            </div>
          </div>

          <div onclick="App.switchTab('customers')" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow cursor-pointer hover:border-red-400 transition flex flex-col justify-between">
            <div class="flex items-center justify-between text-slate-500 mb-2">
              <span class="text-xs sm:text-sm font-semibold">कुल बकाया राशि</span>
              <span class="p-2 bg-red-50 text-red-600 rounded-xl text-lg">⚠️</span>
            </div>
            <div>
              <div class="text-2xl sm:text-3xl font-black text-red-600">₹${totalDue.toLocaleString('en-IN')}</div>
              <p class="text-xs text-red-500 font-medium mt-1">बकाया बदलें/देखें →</p>
            </div>
          </div>

          <div onclick="App.switchTab('payments')" class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow cursor-pointer hover:border-emerald-400 transition flex flex-col justify-between">
            <div class="flex items-center justify-between text-slate-500 mb-2">
              <span class="text-xs sm:text-sm font-semibold">इस माह की वसूली</span>
              <span class="p-2 bg-emerald-50 text-emerald-600 rounded-xl text-lg">💵</span>
            </div>
            <div>
              <div class="text-2xl sm:text-3xl font-black text-emerald-700">₹${thisMonthCollection.toLocaleString('en-IN')}</div>
              <p class="text-xs text-emerald-600 font-medium mt-1">भुगतान इतिहास व एडिट →</p>
            </div>
          </div>
        </div>

        <!-- Live Customer Chat Banner -->
        <div onclick="App.switchTab('chats')" class="bg-gradient-to-r from-blue-700 via-indigo-700 to-sky-700 text-white rounded-2xl p-4 sm:p-5 card-shadow cursor-pointer hover:shadow-lg transition flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div class="flex items-center gap-3.5">
            <div class="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center text-2xl backdrop-blur-sm shadow-inner flex-shrink-0">
              💬
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h4 class="font-bold text-base sm:text-lg">ग्राहक लाइव चैट बॉक्स (Live Customer Chats)</h4>
                ${unreadChatsCount > 0 ? `<span class="px-2.5 py-0.5 bg-amber-400 text-blue-950 font-black text-xs rounded-full animate-bounce">${unreadChatsCount} नए संदेश</span>` : ''}
              </div>
              <p class="text-xs text-blue-100 mt-0.5">ग्राहकों के सवाल, अतिरिक्त अख़बार की मांग और भुगतान के संदेश सीधे यहाँ देखें और तुरंत उत्तर दें</p>
            </div>
          </div>
          <div class="flex items-center gap-2 self-start sm:self-auto">
            <span class="px-4 py-2 bg-white text-blue-900 font-bold text-xs rounded-xl shadow-sm hover:bg-blue-50 transition flex items-center gap-1.5 whitespace-nowrap">
              <span>चैट बॉक्स खोलें</span>
              <span>→</span>
            </span>
          </div>
        </div>

        <!-- Press Indent / Order Table showing today's specific rate -->
        <div class="bg-white rounded-2xl p-4 sm:p-6 border border-slate-100 card-shadow">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
            <div>
              <h3 class="text-lg font-bold text-slate-800 flex items-center gap-2">
                <span>📋 आज की अख़बार मांग एवं दरें (${DAYS_NAMES_HI[stats.dayOfWeek]})</span>
              </h3>
              <p class="text-xs text-slate-500">आज के दिन की विशेष दर के अनुसार कॉपियों की गिनती</p>
            </div>
            <div class="flex items-center gap-2">
              <button onclick="App.switchTab('newspapers')" class="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition">
                📅 7 दिनों की दरें बदलें
              </button>
              <button onclick="window.print()" class="text-xs font-semibold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-lg hover:bg-slate-200 transition">
                🖨️ प्रिंट पर्ची
              </button>
            </div>
          </div>

          <div class="overflow-x-auto mt-4">
            <table class="w-full text-left text-sm">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-semibold text-xs border-y border-slate-200">
                  <th class="py-3 px-3">अख़बार का नाम</th>
                  <th class="py-3 px-3">भाषा</th>
                  <th class="py-3 px-3 text-center">आज आवश्यक कॉपियां</th>
                  <th class="py-3 px-3 text-right">आज की दर (${DAYS_SHORT_HI[stats.dayOfWeek]})</th>
                  <th class="py-3 px-3 text-right">प्रेस खरीद मूल्य</th>
                  <th class="py-3 px-3 text-center">कार्रवाई</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-medium">
                ${store.newspapers.map(paper => {
                  const count = stats.paperCounts[paper.id] || 0;
                  const todayRate = (paper.ratesByDay && paper.ratesByDay[stats.dayOfWeek] != null) 
                    ? parseFloat(paper.ratesByDay[stats.dayOfWeek]) 
                    : (paper.dailyRate || 5);

                  return `
                    <tr class="hover:bg-slate-50/80 transition">
                      <td class="py-3 px-3 font-bold text-slate-800">${paper.name}</td>
                      <td class="py-3 px-3 text-slate-500 text-xs">${paper.language}</td>
                      <td class="py-3 px-3 text-center">
                        <span class="inline-block px-3 py-1 bg-indigo-100 text-indigo-900 font-bold rounded-lg text-sm">${count} प्रतियां</span>
                      </td>
                      <td class="py-3 px-3 text-right font-bold text-slate-800">₹${todayRate.toFixed(2)}</td>
                      <td class="py-3 px-3 text-right text-slate-500">₹${paper.pressCost.toFixed(2)}</td>
                      <td class="py-3 px-3 text-center">
                        <button onclick="App.openEditNewspaperModal(${paper.id})" class="text-xs text-blue-600 font-bold hover:underline">
                          ✏️ दरें बदलें
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  // ================= CUSTOMERS MANAGEMENT =================
  getCustomersHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">👥 ग्राहक प्रबंधन (Customer Directory)</h2>
            <p class="text-xs text-slate-500">ग्राहक के नाम, फोन, पता, अख़बार और बकाया में कभी भी बदलाव करें</p>
          </div>
          <button onclick="App.openAddCustomerModal()" class="touch-btn bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl shadow transition flex items-center justify-center gap-2 text-sm">
            <span>➕ नया ग्राहक जोड़ें</span>
          </button>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-100 card-shadow grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="block text-xs font-semibold text-slate-600 mb-1">खोजें (नाम / मोबाइल / पता)</label>
            <input type="text" id="custSearchInput" placeholder="नाम या मोबाइल लिखें..." class="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-600 mb-1">रूट / लाइन के अनुसार</label>
            <select id="custLineFilter" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">सभी लाइनें (${store.lines.length})</option>
              ${store.lines.map(l => `<option value="${l.id}">${l.name}</option>`).join('')}
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-600 mb-1">बकाया स्थिति</label>
            <select id="custDueFilter" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all">सभी ग्राहक</option>
              <option value="due">केवल बकाया वाले (Due > ₹0)</option>
              <option value="clear">हिसाब साफ़ वाले (₹0 Due)</option>
            </select>
          </div>
        </div>

        <div id="customerListContainer" class="space-y-3"></div>
      </div>
    `;
  },

  attachCustomerEvents() {
    const searchInput = document.getElementById('custSearchInput');
    const lineFilter = document.getElementById('custLineFilter');
    const dueFilter = document.getElementById('custDueFilter');

    const triggerFilter = () => {
      this.renderCustomerCards(
        searchInput ? searchInput.value : '',
        lineFilter ? lineFilter.value : '',
        dueFilter ? dueFilter.value : 'all'
      );
    };

    if (searchInput) searchInput.addEventListener('input', triggerFilter);
    if (lineFilter) lineFilter.addEventListener('change', triggerFilter);
    if (dueFilter) dueFilter.addEventListener('change', triggerFilter);

    triggerFilter();
  },

  renderCustomerCards(searchQuery = '', lineId = '', dueType = 'all') {
    const container = document.getElementById('customerListContainer');
    if (!container) return;

    let filtered = store.customers.filter(c => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q) || c.address.toLowerCase().includes(q);
      const matchLine = !lineId || c.lineId == lineId;
      const due = parseFloat(c.currentDue) || 0;
      let matchDue = true;
      if (dueType === 'due') matchDue = due > 0;
      if (dueType === 'clear') matchDue = due <= 0;
      return matchSearch && matchLine && matchDue;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-8 text-center rounded-2xl border border-slate-100 text-slate-400">
          <div class="text-4xl mb-2">🔍</div>
          <p class="font-medium text-slate-600">कोई ग्राहक नहीं मिला</p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(c => {
      const line = store.lines.find(l => l.id == c.lineId) || { name: 'सामान्य लाइन' };
      const paperNames = (c.papers || []).map(cp => {
        const p = store.newspapers.find(np => np.id == cp.paperId);
        return p ? `${p.name} (${cp.copies} प्रति)` : '';
      }).filter(Boolean).join(', ');

      const due = parseFloat(c.currentDue) || 0;

      return `
        <div class="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 card-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div class="space-y-1.5 flex-1">
            <div class="flex items-center gap-2 flex-wrap">
              <span class="text-base sm:text-lg font-bold text-slate-800">${c.name}</span>
              <span class="text-xs px-2.5 py-0.5 rounded-full font-semibold ${c.status === 'active' ? 'badge-active' : 'badge-inactive'}">
                ${c.status === 'active' ? 'सक्रिय' : 'बंद'}
              </span>
              <span class="text-xs bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-md font-medium">
                📍 ${line.name}
              </span>
            </div>
            
            <p class="text-xs text-slate-500 flex items-center gap-3 flex-wrap">
              <span>📞 ${c.phone}</span>
              <span>🏠 ${c.address}</span>
            </p>

            <div class="pt-1 text-xs text-indigo-700 font-semibold flex items-center gap-1.5">
              <span>📰 अख़बार:</span>
              <span class="text-slate-700">${paperNames || 'कोई अख़बार नहीं'}</span>
            </div>
          </div>

          <div class="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
            <div class="text-right">
              <div class="text-xs font-semibold text-slate-500 flex items-center justify-end gap-1">
                <span>कुल बकाया</span>
                <button onclick="App.openQuickDueEditModal(${c.id})" class="text-blue-600 hover:text-blue-800 text-[11px]" title="बकाया एडिट करें">✏️</button>
              </div>
              <div class="text-lg sm:text-xl font-black ${due > 0 ? 'text-red-600' : 'text-emerald-600'}">
                ₹${due.toLocaleString('en-IN')}
              </div>
            </div>

            <div class="flex items-center gap-1.5 flex-wrap">
              <button onclick="App.openCustomerChat(${c.id})" title="ग्राहक से सीधे चैट करें" class="px-2.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition flex items-center gap-1">
                <span>💬</span>
                <span class="hidden sm:inline">चैट</span>
              </button>

              <button onclick="App.sendWhatsAppBill(${c.id})" title="WhatsApp पर हिसाब भेजें" class="p-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-xl transition">
                📲
              </button>

              <button onclick="App.openRecordPaymentModal(${c.id})" title="पेमेंट लें" class="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition">
                ₹ भुगतान
              </button>

              <button onclick="App.openCustomerLedgerModal(${c.id})" title="खाता-बही देखें" class="px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition">
                खाता
              </button>

              <button onclick="App.openEditCustomerModal(${c.id})" title="ग्राहक एडिट करें" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition">
                ✏️ एडिट
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  openQuickDueEditModal(custId) {
    const cust = store.customers.find(c => c.id == custId);
    if (!cust) return;

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-sm w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 class="text-base font-bold text-slate-800">✏️ बकाया राशि एडिट करें</h3>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-lg">✕</button>
          </div>
          <p class="text-xs text-slate-500">ग्राहक: <b>${cust.name}</b></p>
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">नया कुल बकाया (₹)</label>
            <input type="number" id="quickDueInput" value="${cust.currentDue}" class="w-full px-3 py-2 text-lg font-bold border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
          </div>
          <div class="flex items-center justify-end gap-2 pt-2">
            <button type="button" class="modal-close-btn px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-xl">रद्द करें</button>
            <button type="button" onclick="App.saveQuickDue(${cust.id})" class="px-4 py-2 text-xs font-bold bg-blue-600 text-white rounded-xl hover:bg-blue-700">अपडेट करें</button>
          </div>
        </div>
      </div>
    `;
    this.openModal(html);
  },

  saveQuickDue(custId) {
    const val = parseFloat(document.getElementById('quickDueInput').value) || 0;
    const idx = store.customers.findIndex(c => c.id == custId);
    if (idx !== -1) {
      store.customers[idx].currentDue = val;
      store.save('customers', store.customers);
      this.showToast("बकाया राशि सफलतापूर्वक अपडेट की गई!");
    }
    this.closeAllModals();
    this.renderTab(this.currentTab);
  },

  openAddCustomerModal() {
    this.openCustomerFormModal(null);
  },

  openEditCustomerModal(id) {
    const cust = store.customers.find(c => c.id == id);
    if (!cust) return;
    this.openCustomerFormModal(cust);
  },

  openCustomerFormModal(cust = null) {
    const isEdit = !!cust;
    const currentPapers = cust ? (cust.papers || []) : [{ paperId: store.newspapers[0]?.id || 1, copies: 1 }];

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 class="text-lg font-black text-slate-800">
              ${isEdit ? '✏️ ग्राहक विवरण संपादित करें' : '➕ नया ग्राहक जोड़ें'}
            </h3>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="customerForm" class="space-y-3.5 text-sm">
            <input type="hidden" id="custFormId" value="${isEdit ? cust.id : ''}">

            <div>
              <label class="block font-semibold text-slate-700 mb-1">ग्राहक का पूरा नाम *</label>
              <input type="text" id="custFormName" required value="${isEdit ? cust.name : ''}" placeholder="उदा. डॉ. सतीश अग्रवाल" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">मोबाइल नंबर (WhatsApp) *</label>
                <input type="tel" id="custFormPhone" required value="${isEdit ? cust.phone : ''}" placeholder="उदा. 9829012345" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">रूट / लाइन चुनें *</label>
                <select id="custFormLine" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
                  ${store.lines.map(l => `<option value="${l.id}" ${isEdit && cust.lineId == l.id ? 'selected' : ''}>${l.name}</option>`).join('')}
                </select>
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">मकान नं. / पता *</label>
              <input type="text" id="custFormAddress" required value="${isEdit ? cust.address : ''}" placeholder="उदा. मकान नं. 45, सिविल लाइन्स" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">अख़बार व प्रतियों की संख्या</label>
              <div id="paperSelectionList" class="space-y-2 border border-slate-100 bg-slate-50 p-3 rounded-2xl max-h-48 overflow-y-auto">
                ${store.newspapers.map(p => {
                  const existing = currentPapers.find(cp => cp.paperId == p.id);
                  const isChecked = !!existing;
                  const copies = existing ? existing.copies : 1;
                  return `
                    <div class="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200 text-xs">
                      <label class="flex items-center gap-2 cursor-pointer font-medium text-slate-800">
                        <input type="checkbox" name="paper_check" value="${p.id}" ${isChecked ? 'checked' : ''} class="w-4 h-4 text-blue-600 rounded">
                        <span>${p.name} (सोम: ₹${p.ratesByDay?.[1] || p.dailyRate} | रवि: ₹${p.ratesByDay?.[0] || p.dailyRate})</span>
                      </label>
                      <div class="flex items-center gap-1">
                        <span class="text-slate-500">प्रतियां:</span>
                        <input type="number" min="1" max="10" id="copies_${p.id}" value="${copies}" class="w-14 px-2 py-1 border border-slate-200 rounded text-center font-bold">
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">वर्तमान कुल बकाया (₹ Edit Due)</label>
                <input type="number" id="custFormDue" value="${isEdit ? cust.currentDue : '0'}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-bold">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">खाता स्थिति</label>
                <select id="custFormStatus" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
                  <option value="active" ${isEdit && cust.status === 'active' ? 'selected' : ''}>सक्रिय (Active)</option>
                  <option value="inactive" ${isEdit && cust.status === 'inactive' ? 'selected' : ''}>अस्थायी बंद (Inactive)</option>
                </select>
              </div>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              ${isEdit ? `
                <button type="button" onclick="App.deleteCustomer(${cust.id})" class="text-red-600 font-bold px-3 py-2 text-xs hover:bg-red-50 rounded-xl mr-auto transition">
                  🗑️ ग्राहक हटाएं
                </button>
              ` : ''}
              <button type="button" class="modal-close-btn px-4 py-2.5 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl transition">रद्द करें</button>
              <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition">
                ${isEdit ? 'अपडेट सुरक्षित करें' : 'नया ग्राहक जोड़ें'}
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('customerForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveCustomerForm();
    });
  },

  saveCustomerForm() {
    const id = document.getElementById('custFormId').value;
    const name = document.getElementById('custFormName').value.trim();
    const phone = document.getElementById('custFormPhone').value.trim();
    const lineId = parseInt(document.getElementById('custFormLine').value);
    const address = document.getElementById('custFormAddress').value.trim();
    const currentDue = parseFloat(document.getElementById('custFormDue').value) || 0;
    const status = document.getElementById('custFormStatus').value;

    const selectedPapers = [];
    document.querySelectorAll('input[name="paper_check"]:checked').forEach(cb => {
      const pId = parseInt(cb.value);
      const copiesInput = document.getElementById(`copies_${pId}`);
      const copies = copiesInput ? parseInt(copiesInput.value) || 1 : 1;
      selectedPapers.push({ paperId: pId, copies });
    });

    if (selectedPapers.length === 0) {
      alert("कृपया कम से कम एक अख़बार अवश्य चुनें!");
      return;
    }

    if (id) {
      const index = store.customers.findIndex(c => c.id == id);
      if (index !== -1) {
        store.customers[index] = {
          ...store.customers[index],
          name, phone, lineId, address,
          papers: selectedPapers,
          currentDue, status
        };
        store.save('customers', store.customers);
        this.showToast("ग्राहक विवरण सफलतापूर्वक अपडेट किया गया!");
      }
    } else {
      const newCust = {
        id: Date.now(),
        name, phone, lineId, address,
        papers: selectedPapers,
        openingDue: currentDue,
        currentDue,
        status,
        startDate: new Date().toISOString().slice(0, 10)
      };
      store.customers.unshift(newCust);
      store.save('customers', store.customers);
      this.showToast("नया ग्राहक सफलतापूर्वक जोड़ा गया!");
    }

    this.closeAllModals();
    this.renderTab(this.currentTab);
  },

  deleteCustomer(id) {
    if (confirm("क्या आप वाकई इस ग्राहक को हटाना चाहते हैं?")) {
      store.customers = store.customers.filter(c => c.id != id);
      store.save('customers', store.customers);
      this.showToast("ग्राहक हटा दिया गया।", "info");
      this.closeAllModals();
      this.renderTab(this.currentTab);
    }
  },

  // ================= CUSTOMER LEDGER MODAL =================
  openCustomerLedgerModal(custId) {
    const cust = store.customers.find(c => c.id == custId);
    if (!cust) return;

    const line = store.lines.find(l => l.id == cust.lineId) || { name: 'सामान्य लाइन' };
    const payments = store.payments.filter(p => p.customerId == custId);
    const vacations = store.vacations.filter(v => v.customerId == custId);

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-2xl w-full p-6 card-shadow modal-content space-y-5">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 class="text-lg font-black text-slate-800">📖 ग्राहक खाता-बही: ${cust.name}</h3>
              <p class="text-xs text-slate-500">📞 ${cust.phone} | 🏠 ${cust.address} | 📍 ${line.name}</p>
            </div>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div>
              <div class="text-xs text-slate-500 flex items-center gap-1">
                <span>वर्तमान कुल बकाया</span>
                <button onclick="App.openQuickDueEditModal(${cust.id})" class="text-blue-600 text-[10px]">✏️ एडिट</button>
              </div>
              <div class="text-xl font-black ${cust.currentDue > 0 ? 'text-red-600' : 'text-emerald-600'}">₹${cust.currentDue}</div>
            </div>
            <div>
              <div class="text-xs text-slate-500">कुल दर्ज भुगतान</div>
              <div class="text-xl font-bold text-emerald-700">₹${payments.reduce((a, b) => a + (parseFloat(b.amount) || 0), 0)}</div>
            </div>
            <div>
              <div class="text-xs text-slate-500">कुल छुट्टियां</div>
              <div class="text-xl font-bold text-slate-700">${vacations.length} बार</div>
            </div>
          </div>

          <div>
            <div class="flex items-center justify-between mb-2">
              <h4 class="font-bold text-sm text-slate-700">💵 भुगतान इतिहास</h4>
              <button onclick="App.openRecordPaymentModal(${cust.id})" class="text-xs text-emerald-700 font-bold hover:underline">+ नया भुगतान</button>
            </div>
            ${payments.length === 0 ? '<p class="text-xs text-slate-400 bg-slate-50 p-3 rounded-xl">कोई भुगतान दर्ज नहीं है।</p>' : `
              <div class="space-y-2 max-h-40 overflow-y-auto">
                ${payments.map(p => `
                  <div class="flex items-center justify-between p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl text-xs">
                    <div>
                      <div class="font-bold text-slate-800">रसीद: ${p.receiptNo} | तारीख: ${p.date}</div>
                      <div class="text-slate-500">माध्यम: ${p.mode} ${p.note ? `| नोट: ${p.note}` : ''}</div>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="font-black text-emerald-700 text-sm">₹${p.amount}</span>
                      <button onclick="App.openEditPaymentModal(${p.id})" class="p-1 text-blue-600 hover:bg-white rounded">✏️</button>
                      <button onclick="App.deletePayment(${p.id})" class="p-1 text-red-600 hover:bg-white rounded">🗑️</button>
                    </div>
                  </div>
                `).join('')}
              </div>
            `}
          </div>

          <div>
            <div class="flex items-center justify-between mb-2">
              <h4 class="font-bold text-sm text-slate-700">🏖️ छुट्टी / रोक इतिहास</h4>
              <button onclick="App.openAddVacationModal()" class="text-xs text-purple-700 font-bold hover:underline">+ नई छुट्टी</button>
            </div>
            ${vacations.length === 0 ? '<p class="text-xs text-slate-400 bg-slate-50 p-3 rounded-xl">कोई छुट्टी दर्ज नहीं है।</p>' : `
              <div class="space-y-2 max-h-36 overflow-y-auto">
                ${vacations.map(v => `
                  <div class="p-3 bg-amber-50/50 border border-amber-100 rounded-xl text-xs flex items-center justify-between">
                    <div>
                      <div class="font-bold text-slate-800">अवधि: ${v.fromDate} से ${v.toDate}</div>
                      <div class="text-slate-500">कारण: ${v.reason || 'निजी कार्य'}</div>
                    </div>
                    <div class="flex items-center gap-2">
                      <button onclick="App.openEditVacationModal(${v.id})" class="p-1 text-blue-600 hover:bg-white rounded">✏️</button>
                      <button onclick="App.deleteVacation(${v.id})" class="p-1 text-red-600 hover:bg-white rounded">🗑️</button>
                    </div>
                  </div>
                `).join('')}
              </div>
            `}
          </div>

          <div class="flex items-center justify-between pt-3 border-t border-slate-100">
            <button onclick="App.openEditCustomerModal(${cust.id})" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-xl text-xs transition">
              ✏️ ग्राहक विवरण एडिट करें
            </button>
            <button class="modal-close-btn px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition">
              बंद करें
            </button>
          </div>
        </div>
      </div>
    `;

    this.openModal(html);
  },

  // ================= PAYMENTS MODULE =================
  getPaymentsHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">💰 भुगतान एवं कलेक्शन (Payments & Receipts)</h2>
            <p class="text-xs text-slate-500">किसी भी भुगतान राशि, तारीख या माध्यम को एडिट करें या नया भुगतान लें</p>
          </div>
          <button onclick="App.openRecordPaymentModal()" class="touch-btn bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-xl shadow transition flex items-center justify-center gap-2 text-sm">
            <span>➕ भुगतान दर्ज करें</span>
          </button>
        </div>

        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow">
          <h3 class="font-bold text-base text-slate-800 mb-3">ताज़ा भुगतान रसीदें (Edit / Delete / Print)</h3>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-semibold text-xs border-y border-slate-200">
                  <th class="py-3 px-3">रसीद सं.</th>
                  <th class="py-3 px-3">तारीख</th>
                  <th class="py-3 px-3">ग्राहक का नाम</th>
                  <th class="py-3 px-3">माध्यम</th>
                  <th class="py-3 px-3 text-right">राशि (₹)</th>
                  <th class="py-3 px-3 text-center">कार्रवाई</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-medium">
                ${store.payments.map(p => {
                  const cust = store.customers.find(c => c.id == p.customerId) || { name: 'अज्ञात ग्राहक' };
                  return `
                    <tr class="hover:bg-slate-50 transition">
                      <td class="py-3 px-3 font-bold text-blue-700">${p.receiptNo}</td>
                      <td class="py-3 px-3 text-slate-500 text-xs">${p.date}</td>
                      <td class="py-3 px-3 font-bold text-slate-800">${cust.name}</td>
                      <td class="py-3 px-3 text-slate-600 text-xs">${p.mode}</td>
                      <td class="py-3 px-3 text-right font-black text-emerald-700">₹${p.amount}</td>
                      <td class="py-3 px-3 text-center">
                        <div class="flex items-center justify-center gap-1.5">
                          <button onclick="App.openEditPaymentModal(${p.id})" class="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-semibold">
                            ✏️ एडिट
                          </button>
                          <button onclick="App.printReceipt(${p.id})" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold">
                            🖨️
                          </button>
                          <button onclick="App.deletePayment(${p.id})" class="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-xs font-semibold">
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  openRecordPaymentModal(preselectedCustId = null) {
    this.openPaymentFormModal(null, preselectedCustId);
  },

  openEditPaymentModal(paymentId) {
    const payment = store.payments.find(p => p.id == paymentId);
    if (!payment) return;
    this.openPaymentFormModal(payment);
  },

  openPaymentFormModal(payment = null, preselectedCustId = null) {
    const isEdit = !!payment;
    const today = new Date().toISOString().slice(0, 10);
    const nextReceiptNo = payment ? payment.receiptNo : ("REC-" + (1000 + store.payments.length + 1));
    const custId = payment ? payment.customerId : preselectedCustId;

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 class="text-lg font-black text-slate-800">
              ${isEdit ? '✏️ भुगतान विवरण संपादित करें' : '💰 भुगतान दर्ज करें'}
            </h3>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="paymentForm" class="space-y-3.5 text-sm">
            <input type="hidden" id="payFormId" value="${isEdit ? payment.id : ''}">

            <div>
              <label class="block font-semibold text-slate-700 mb-1">ग्राहक चुनें *</label>
              <select id="payCustSelect" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                <option value="">-- ग्राहक का नाम चुनें --</option>
                ${store.customers.map(c => `
                  <option value="${c.id}" ${custId == c.id ? 'selected' : ''}>
                    ${c.name} (बकाया: ₹${c.currentDue})
                  </option>
                `).join('')}
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">प्राप्त राशि (₹) *</label>
                <input type="number" id="payAmount" min="1" step="1" required value="${isEdit ? payment.amount : ''}" placeholder="उदा. 350" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold text-emerald-700">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">तारीख *</label>
                <input type="date" id="payDate" value="${isEdit ? payment.date : today}" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">भुगतान का माध्यम *</label>
              <select id="payMode" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                <option value="नगद (Cash)" ${isEdit && payment.mode === 'नगद (Cash)' ? 'selected' : ''}>नगद (Cash)</option>
                <option value="UPI (PhonePe)" ${isEdit && payment.mode.includes('PhonePe') ? 'selected' : ''}>PhonePe</option>
                <option value="UPI (Google Pay)" ${isEdit && payment.mode.includes('Google') ? 'selected' : ''}>Google Pay</option>
                <option value="UPI (Paytm)" ${isEdit && payment.mode.includes('Paytm') ? 'selected' : ''}>Paytm</option>
                <option value="सीधा बैंक ट्रांसफर" ${isEdit && payment.mode.includes('बैंक') ? 'selected' : ''}>बैंक ट्रांसफर</option>
              </select>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">टिप्पणी / विवरण</label>
              <input type="text" id="payNote" value="${isEdit ? (payment.note || '') : ''}" placeholder="उदा. अक्टूबर का बिल भुगतान" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button type="button" class="modal-close-btn px-4 py-2.5 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl transition">रद्द करें</button>
              <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition">
                ${isEdit ? 'अपडेट सुरक्षित करें' : 'भुगतान जमा करें'}
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('paymentForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const pId = document.getElementById('payFormId').value;
      const targetCustId = parseInt(document.getElementById('payCustSelect').value);
      const newAmount = parseFloat(document.getElementById('payAmount').value);
      const date = document.getElementById('payDate').value;
      const mode = document.getElementById('payMode').value;
      const note = document.getElementById('payNote').value.trim();

      const custIndex = store.customers.findIndex(c => c.id == targetCustId);
      if (custIndex === -1) return;

      if (pId) {
        const payIdx = store.payments.findIndex(p => p.id == pId);
        if (payIdx !== -1) {
          const oldPayment = store.payments[payIdx];
          const diff = newAmount - oldPayment.amount;

          store.payments[payIdx] = {
            ...oldPayment,
            customerId: targetCustId,
            amount: newAmount,
            date,
            mode,
            note
          };
          store.save('payments', store.payments);

          store.customers[custIndex].currentDue = Math.max(0, (store.customers[custIndex].currentDue || 0) - diff);
          store.save('customers', store.customers);

          this.showToast("भुगतान विवरण सफलतापूर्वक अपडेट किया गया!");
        }
      } else {
        const newPayment = {
          id: Date.now(),
          receiptNo: nextReceiptNo,
          customerId: targetCustId,
          date,
          amount: newAmount,
          mode,
          note
        };
        store.payments.unshift(newPayment);
        store.save('payments', store.payments);

        store.customers[custIndex].currentDue = Math.max(0, (store.customers[custIndex].currentDue || 0) - newAmount);
        store.save('customers', store.customers);

        this.showToast(`₹${newAmount} का भुगतान दर्ज हो गया!`);
      }

      this.closeAllModals();
      this.renderTab(this.currentTab);
    });
  },

  deletePayment(paymentId) {
    const p = store.payments.find(pay => pay.id == paymentId);
    if (!p) return;

    if (confirm(`क्या आप रसीद ${p.receiptNo} (₹${p.amount}) को हटाना चाहते हैं? यह राशि ग्राहक के बकाये में पुनः जुड़ जाएगी।`)) {
      const custIdx = store.customers.findIndex(c => c.id == p.customerId);
      if (custIdx !== -1) {
        store.customers[custIdx].currentDue = (store.customers[custIdx].currentDue || 0) + p.amount;
        store.save('customers', store.customers);
      }

      store.payments = store.payments.filter(pay => pay.id != paymentId);
      store.save('payments', store.payments);

      this.showToast("भुगतान हटा दिया गया और बकाया अपडेट कर दिया गया।", "info");
      this.renderTab(this.currentTab);
    }
  },

  printReceipt(paymentId) {
    const p = store.payments.find(pay => pay.id == paymentId);
    if (!p) return;
    const cust = store.customers.find(c => c.id == p.customerId) || { name: 'ग्राहक', phone: '-' };

    const printWin = window.open('', '_blank');
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>रसीद - ${p.receiptNo}</title>
        <style>
          body { font-family: sans-serif; padding: 20px; max-width: 320px; margin: auto; border: 1px dashed #444; }
          .center { text-align: center; }
          .row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
          .bold { font-weight: bold; }
          .line { border-bottom: 1px dashed #888; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="center">
          <h2 style="margin: 0;">${store.agency.name}</h2>
          <p style="margin: 2px 0; font-size: 12px;">वितरक: ${store.agency.owner} (${store.agency.phone})</p>
          <div class="line"></div>
          <h3 style="margin: 4px 0;">भुगतान रसीद (Payment Receipt)</h3>
        </div>
        <div class="row"><span class="bold">रसीद सं:</span><span>${p.receiptNo}</span></div>
        <div class="row"><span class="bold">तारीख:</span><span>${p.date}</span></div>
        <div class="row"><span class="bold">ग्राहक:</span><span>${cust.name}</span></div>
        <div class="row"><span class="bold">मोबाइल:</span><span>${cust.phone}</span></div>
        <div class="row"><span class="bold">माध्यम:</span><span>${p.mode}</span></div>
        <div class="line"></div>
        <div class="row" style="font-size: 16px;"><span class="bold">प्राप्त राशि:</span><span class="bold">₹${p.amount}</span></div>
        <div class="row"><span class="bold">शेष बकाया:</span><span>₹${cust.currentDue}</span></div>
        <div class="line"></div>
        <div class="center" style="font-size: 11px; color: #555;">
          धन्यवाद! समाचार पत्र से जुड़े रहें।
        </div>
      </body>
      </html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => { printWin.print(); }, 250);
  },

  // ================= MONTHLY BILLING WITH DAY-WISE CALCULATION =================
  getBillingHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">🧾 मासिक बिलिंग (Day-wise Accurate Billing)</h2>
            <p class="text-xs text-slate-500">सप्ताह के प्रत्येक दिन की अलग-अलग दरों और छुट्टियों के हिसाब से सटीक बिल</p>
          </div>
          
          <div class="flex items-center gap-2">
            <input type="month" id="billingMonthSelect" value="${this.selectedMonth}" class="px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold">
            <button onclick="App.autoGenerateMonthlyBills()" class="touch-btn bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-xl shadow transition text-sm">
              ⚡ सभी बिल बनाएं
            </button>
          </div>
        </div>

        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow">
          <div class="flex items-center justify-between mb-4">
            <h3 class="font-bold text-slate-800 text-base">ग्राहकों के बिल (${this.selectedMonth})</h3>
            <button onclick="App.sendAllDueRemindersWhatsApp()" class="text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition">
              📲 सभी को WhatsApp बिल भेजें
            </button>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-semibold text-xs border-y border-slate-200">
                  <th class="py-3 px-3">ग्राहक का नाम</th>
                  <th class="py-3 px-3">अख़बार</th>
                  <th class="py-3 px-3 text-center">सक्रिय दिन</th>
                  <th class="py-3 px-3 text-center">छुट्टी दिन</th>
                  <th class="py-3 px-3 text-right">माह का शुल्क</th>
                  <th class="py-3 px-3 text-right">कुल देय (Total)</th>
                  <th class="py-3 px-3 text-center">कार्रवाई (Edit / Share)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-medium">
                ${store.customers.map(c => {
                  const billCalc = this.calculateCustomerMonthlyBill(c, this.selectedMonth);
                  return `
                    <tr class="hover:bg-slate-50 transition">
                      <td class="py-3 px-3">
                        <div class="font-bold text-slate-800">${c.name}</div>
                        <div class="text-xs text-slate-400">${c.phone}</div>
                      </td>
                      <td class="py-3 px-3 text-xs text-slate-600">
                        ${(c.papers || []).map(cp => {
                          const p = store.newspapers.find(np => np.id == cp.paperId);
                          return p ? p.name : '';
                        }).filter(Boolean).join(', ')}
                      </td>
                      <td class="py-3 px-3 text-center text-xs font-bold text-emerald-700">${billCalc.activeDays} दिन</td>
                      <td class="py-3 px-3 text-center text-xs font-bold ${billCalc.pausedDays > 0 ? 'text-amber-600' : 'text-slate-400'}">
                        ${billCalc.pausedDays > 0 ? `${billCalc.pausedDays} दिन छूट` : '0'}
                      </td>
                      <td class="py-3 px-3 text-right text-slate-700">₹${billCalc.monthlyCharge.toFixed(2)}</td>
                      <td class="py-3 px-3 text-right font-black ${billCalc.totalPayable > 0 ? 'text-red-600' : 'text-emerald-700'}">
                        ₹${billCalc.totalPayable.toFixed(2)}
                      </td>
                      <td class="py-3 px-3 text-center">
                        <div class="flex items-center justify-center gap-1.5">
                          <button onclick="App.openEditBillModal(${c.id}, '${this.selectedMonth}')" class="p-2 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-xs font-bold" title="बिल एडिट करें (छूट/शुल्क)">
                            ✏️ एडिट
                          </button>
                          <button onclick="App.sendWhatsAppBill(${c.id}, '${this.selectedMonth}')" class="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-lg text-xs font-semibold" title="WhatsApp भेजें">
                            📲
                          </button>
                          <button onclick="App.printCustomerBill(${c.id}, '${this.selectedMonth}')" class="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold" title="बिल प्रिंट">
                            🖨️
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  attachBillingEvents() {
    const monthSelect = document.getElementById('billingMonthSelect');
    if (monthSelect) {
      monthSelect.addEventListener('change', (e) => {
        this.selectedMonth = e.target.value;
        this.renderTab('billing');
      });
    }
  },

  // Calculate bill day-by-day honoring the specific day-of-week rate
  calculateCustomerMonthlyBill(cust, yearMonth) {
    const [year, month] = yearMonth.split('-').map(Number);
    const daysInMonth = new Date(year, month, 0).getDate();

    // Get customer's vacations in this month
    const custVacations = store.vacations.filter(v => v.customerId == cust.id);

    let activeDays = 0;
    let pausedDays = 0;
    let totalPaperCharge = 0;

    for (let day = 1; day <= daysInMonth; day++) {
      const dayStr = day < 10 ? '0' + day : '' + day;
      const curDateStr = `${yearMonth}-${dayStr}`;
      const curDateObj = new Date(year, month - 1, day);
      const dayOfWeek = curDateObj.getDay(); // 0 = Sun, 1 = Mon ... 6 = Sat

      // Check if this date falls within any vacation
      const isPaused = custVacations.some(v => v.fromDate <= curDateStr && v.toDate >= curDateStr);

      if (isPaused) {
        pausedDays++;
      } else {
        activeDays++;
        // Calculate cost for each paper on this particular day of the week
        (cust.papers || []).forEach(cp => {
          const p = store.newspapers.find(np => np.id == cp.paperId);
          if (p) {
            const dayRate = (p.ratesByDay && p.ratesByDay[dayOfWeek] != null) 
              ? parseFloat(p.ratesByDay[dayOfWeek]) 
              : (p.dailyRate || 5);
            totalPaperCharge += dayRate * (cp.copies || 1);
          }
        });
      }
    }

    let monthlyCharge = totalPaperCharge;

    // Apply any custom adjustment for this customer and month
    const adjKey = `${cust.id}_${yearMonth}`;
    const adj = store.billAdjustments[adjKey] || {};

    if (adj.manualDays !== undefined && adj.manualDays !== null && adj.manualDays !== '') {
      activeDays = parseInt(adj.manualDays);
    }

    const discount = parseFloat(adj.discount) || 0;
    const extraFee = parseFloat(adj.extraFee) || 0;

    monthlyCharge = Math.max(0, monthlyCharge - discount + extraFee);

    if (adj.overrideTotal !== undefined && adj.overrideTotal !== null && adj.overrideTotal !== '') {
      monthlyCharge = parseFloat(adj.overrideTotal);
    }

    const oldDue = parseFloat(cust.currentDue) || 0;
    const totalPayable = monthlyCharge + oldDue;

    return {
      daysInMonth,
      pausedDays,
      activeDays,
      discount,
      extraFee,
      monthlyCharge,
      oldDue,
      totalPayable,
      note: adj.note || ''
    };
  },

  openEditBillModal(custId, monthStr) {
    const cust = store.customers.find(c => c.id == custId);
    if (!cust) return;

    const adjKey = `${custId}_${monthStr}`;
    const adj = store.billAdjustments[adjKey] || {};
    const baseBill = this.calculateCustomerMonthlyBill(cust, monthStr);

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 class="text-lg font-black text-slate-800">✏️ बिल संपादित करें (Edit Bill)</h3>
              <p class="text-xs text-slate-500">ग्राहक: <b>${cust.name}</b> (${monthStr})</p>
            </div>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="editBillForm" class="space-y-3.5 text-sm">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">सक्रिय दिन (Active Days)</label>
                <input type="number" id="adjDays" value="${adj.manualDays !== undefined ? adj.manualDays : baseBill.activeDays}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">विशेष छूट (Discount ₹)</label>
                <input type="number" id="adjDiscount" value="${adj.discount || 0}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">अतिरिक्त डिलीवरी शुल्क (₹)</label>
                <input type="number" id="adjExtra" value="${adj.extraFee || 0}" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">सीधी कुल बिल राशि (वैकल्पिक)</label>
                <input type="number" id="adjOverride" value="${adj.overrideTotal || ''}" placeholder="उदा. 300" class="w-full px-3 py-2 border border-slate-200 rounded-xl font-bold text-blue-700">
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">बिल नोट (WhatsApp में दिखेगा)</label>
              <input type="text" id="adjNote" value="${adj.note || ''}" placeholder="उदा. ₹20 छूट दी गई" class="w-full px-3 py-2 border border-slate-200 rounded-xl">
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button type="button" class="modal-close-btn px-4 py-2 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl">रद्द करें</button>
              <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2 rounded-xl text-sm transition">
                बिल अपडेट करें
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('editBillForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const manualDays = document.getElementById('adjDays').value;
      const discount = parseFloat(document.getElementById('adjDiscount').value) || 0;
      const extraFee = parseFloat(document.getElementById('adjExtra').value) || 0;
      const overrideTotal = document.getElementById('adjOverride').value;
      const note = document.getElementById('adjNote').value.trim();

      store.billAdjustments[adjKey] = {
        manualDays: manualDays ? parseInt(manualDays) : null,
        discount,
        extraFee,
        overrideTotal: overrideTotal ? parseFloat(overrideTotal) : null,
        note
      };
      store.save('billAdjustments', store.billAdjustments);

      this.showToast("बिल सफलतापूर्वक अपडेट हो गया!");
      this.closeAllModals();
      this.renderTab('billing');
    });
  },

  autoGenerateMonthlyBills() {
    this.showToast(`${this.selectedMonth} के सभी ग्राहकों के मासिक बिल तैयार हो गए!`);
    this.renderTab('billing');
  },

  sendWhatsAppBill(custId, monthStr = null) {
    const cust = store.customers.find(c => c.id == custId);
    if (!cust) return;

    const m = monthStr || this.selectedMonth;
    const bill = this.calculateCustomerMonthlyBill(cust, m);

    const papers = (cust.papers || []).map(cp => {
      const p = store.newspapers.find(np => np.id == cp.paperId);
      return p ? `${p.name}` : '';
    }).filter(Boolean).join(' + ');

    const notePart = bill.note ? `\n📌 *नोट:* ${bill.note}` : '';

    const message = 
`🙏 नमस्ते ${cust.name} जी,

*${store.agency.name}* की ओर से आपका *अख़बार मासिक बिल* निम्न प्रकार है:
━━━━━━━━━━━━━━━━━
📅 *माह:* ${m}
📰 *अख़बार:* ${papers}
🗓️ *सक्रिय दिन:* ${bill.activeDays} दिन
🏖️ *छुट्टी/छूट दिन:* ${bill.pausedDays} दिन
💵 *इस माह का शुल्क:* ₹${bill.monthlyCharge.toFixed(2)}
⚠️ *पिछला बकाया:* ₹${bill.oldDue.toFixed(2)}${notePart}
━━━━━━━━━━━━━━━━━
👉 *कुल देय राशि:* ₹${bill.totalPayable.toFixed(2)}
━━━━━━━━━━━━━━━━━

कृपया ऑनलाइन भुगतान हेतु हमारे UPI पर भेजें:
📲 *UPI ID:* ${store.agency.upiId}

सम्पर्क: ${store.agency.phone}
धन्यवाद एवं शुभ दिन! ✨`;

    const encoded = encodeURI(message);
    const cleanPhone = cust.phone.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;
    
    window.open(`https://wa.me/${phoneWithCountry}?text=${encoded}`, '_blank');
  },

  sendAllDueRemindersWhatsApp() {
    const dueCustomers = store.customers.filter(c => (parseFloat(c.currentDue) || 0) > 0);
    if (dueCustomers.length === 0) {
      alert("किसी भी ग्राहक पर बकाया नहीं है!");
      return;
    }
    alert(`${dueCustomers.length} ग्राहकों पर बकाया है। आप हर ग्राहक के सामने बने WhatsApp बटन से उन्हें एक-एक करके संदेश भेज सकते हैं।`);
  },

  printCustomerBill(custId, monthStr) {
    const cust = store.customers.find(c => c.id == custId);
    if (!cust) return;
    const bill = this.calculateCustomerMonthlyBill(cust, monthStr || this.selectedMonth);

    const printWin = window.open('', '_blank');
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>मासिक बिल - ${cust.name}</title>
        <style>
          body { font-family: sans-serif; padding: 20px; max-width: 340px; margin: auto; border: 1px dashed #333; }
          .center { text-align: center; }
          .row { display: flex; justify-content: space-between; margin: 6px 0; font-size: 13px; }
          .bold { font-weight: bold; }
          .line { border-bottom: 1px dashed #666; margin: 10px 0; }
        </style>
      </head>
      <body>
        <div class="center">
          <h2 style="margin: 0;">${store.agency.name}</h2>
          <p style="margin: 3px 0; font-size: 12px;">वितरक: ${store.agency.owner} (${store.agency.phone})</p>
          <div class="line"></div>
          <h3 style="margin: 4px 0;">समाचार पत्र मासिक इनवॉइस</h3>
          <p style="font-size: 12px; margin: 0;">माह: ${monthStr || this.selectedMonth}</p>
        </div>
        <div class="line"></div>
        <div class="row"><span class="bold">ग्राहक:</span><span>${cust.name}</span></div>
        <div class="row"><span class="bold">मोबाइल:</span><span>${cust.phone}</span></div>
        <div class="row"><span class="bold">पता:</span><span>${cust.address}</span></div>
        <div class="line"></div>
        <div class="row"><span>सक्रिय वितरण दिन:</span><span>${bill.activeDays} दिन</span></div>
        <div class="row"><span>छुट्टी/रोक दिन:</span><span>${bill.pausedDays} दिन</span></div>
        <div class="row"><span>माह का बिल:</span><span>₹${bill.monthlyCharge.toFixed(2)}</span></div>
        <div class="row"><span>पिछला बकाया:</span><span>₹${bill.oldDue.toFixed(2)}</span></div>
        <div class="line"></div>
        <div class="row" style="font-size: 17px;"><span class="bold">कुल देय राशि:</span><span class="bold">₹${bill.totalPayable.toFixed(2)}</span></div>
        <div class="line"></div>
        <div class="center" style="font-size: 11px;">
          UPI से भुगतान करें: <b>${store.agency.upiId}</b><br>
          समय पर भुगतान करने के लिए धन्यवाद!
        </div>
      </body>
      </html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => { printWin.print(); }, 250);
  },

  // ================= LINES & HAWKERS ROUTE SHEET =================
  getLinesHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">🚴‍♂️ लाइन एवं हॉकर प्रबंधन (Routes & Hawkers)</h2>
            <p class="text-xs text-slate-500">लाइनों के नाम, हॉकर का नाम, फोन और कमीशन कभी भी एडिट करें</p>
          </div>
          <button onclick="App.openAddLineModal()" class="touch-btn bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl shadow transition text-sm">
            ➕ नई लाइन जोड़ें
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          ${store.lines.map(line => {
            const custs = store.customers.filter(c => c.lineId == line.id);
            return `
              <div class="bg-white p-5 rounded-2xl border border-slate-100 card-shadow space-y-3 flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">लाइन सं. ${line.id}</span>
                    <span class="text-xs text-slate-400 font-medium">${custs.length} ग्राहक</span>
                  </div>
                  <h3 class="text-base font-bold text-slate-800 mt-2">${line.name}</h3>
                  <div class="text-xs text-slate-500 mt-2 space-y-1">
                    <p>🚴‍♂️ <b>हॉकर:</b> ${line.hawkerName}</p>
                    <p>📞 <b>संपर्क:</b> ${line.hawkerPhone}</p>
                    <p>💵 <b>कमीशन:</b> ₹${line.commissionPerCopy || 1.2} प्रति कॉपी</p>
                  </div>
                </div>

                <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button onclick="App.printHawkerSheet(${line.id})" class="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition">
                    📋 वितरण शीट
                  </button>
                  <button onclick="App.openEditLineModal(${line.id})" class="text-blue-600 hover:text-blue-800 text-xs font-bold">
                    ✏️ एडिट करें
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  },

  openAddLineModal() {
    this.openLineFormModal(null);
  },

  openEditLineModal(id) {
    const line = store.lines.find(l => l.id == id);
    if (!line) return;
    this.openLineFormModal(line);
  },

  openLineFormModal(line = null) {
    const isEdit = !!line;
    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 class="text-lg font-black text-slate-800">${isEdit ? '✏️ लाइन संपादित करें' : '➕ नई लाइन जोड़ें'}</h3>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="lineForm" class="space-y-3.5 text-sm">
            <input type="hidden" id="lineFormId" value="${isEdit ? line.id : ''}">

            <div>
              <label class="block font-semibold text-slate-700 mb-1">लाइन / रूट का नाम *</label>
              <input type="text" id="lineFormName" required value="${isEdit ? line.name : ''}" placeholder="उदा. लाइन 4 - मानसरोवर कॉलोनी" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">हॉकर (डिलीवरी बॉय) का नाम *</label>
              <input type="text" id="lineFormHawker" required value="${isEdit ? line.hawkerName : ''}" placeholder="उदा. सोहन लाल" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">हॉकर फोन नंबर</label>
                <input type="tel" id="lineFormPhone" value="${isEdit ? line.hawkerPhone : ''}" placeholder="9811122334" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">कमीशन (₹ प्रति कॉपी)</label>
                <input type="number" step="0.1" id="lineFormCommission" value="${isEdit ? line.commissionPerCopy : '1.2'}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              ${isEdit ? `
                <button type="button" onclick="App.deleteLine(${line.id})" class="text-red-600 font-bold px-3 py-2 text-xs hover:bg-red-50 rounded-xl mr-auto transition">
                  🗑️ हटाएं
                </button>
              ` : ''}
              <button type="button" class="modal-close-btn px-4 py-2.5 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl transition">रद्द करें</button>
              <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition">
                सुरक्षित करें
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('lineForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('lineFormId').value;
      const name = document.getElementById('lineFormName').value.trim();
      const hawkerName = document.getElementById('lineFormHawker').value.trim();
      const hawkerPhone = document.getElementById('lineFormPhone').value.trim();
      const commissionPerCopy = parseFloat(document.getElementById('lineFormCommission').value) || 1.2;

      if (id) {
        const idx = store.lines.findIndex(l => l.id == id);
        if (idx !== -1) {
          store.lines[idx] = { ...store.lines[idx], name, hawkerName, hawkerPhone, commissionPerCopy };
          store.save('lines', store.lines);
          this.showToast("लाइन विवरण अपडेट किया गया!");
        }
      } else {
        const newLine = {
          id: Date.now(),
          name, hawkerName, hawkerPhone, commissionPerCopy
        };
        store.lines.push(newLine);
        store.save('lines', store.lines);
        this.showToast("नई लाइन सफलतापूर्वक जोड़ी गई!");
      }

      this.closeAllModals();
      this.renderTab('lines');
    });
  },

  deleteLine(id) {
    if (confirm("क्या आप इस लाइन को हटाना चाहते हैं?")) {
      store.lines = store.lines.filter(l => l.id != id);
      store.save('lines', store.lines);
      this.showToast("लाइन हटा दी गई।");
      this.closeAllModals();
      this.renderTab('lines');
    }
  },

  printHawkerSheet(lineId) {
    const line = store.lines.find(l => l.id == lineId);
    if (!line) return;
    const custs = store.customers.filter(c => c.lineId == lineId && c.status === 'active');
    const today = new Date().toISOString().slice(0, 10);

    const printWin = window.open('', '_blank');
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>हॉकर वितरण शीट - ${line.name}</title>
        <style>
          body { font-family: sans-serif; padding: 15px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
          th, td { border: 1px solid #444; padding: 6px; text-align: left; }
          th { background: #f0f0f0; }
          .center { text-align: center; }
        </style>
      </head>
      <body>
        <div style="text-align: center;">
          <h2 style="margin: 0;">${store.agency.name}</h2>
          <h3 style="margin: 4px 0;">दैनिक वितरण चार्ट (${line.name})</h3>
          <p style="margin: 0; font-size: 13px;"><b>हॉकर:</b> ${line.hawkerName} (${line.hawkerPhone}) | <b>तारीख:</b> ${today}</p>
        </div>
        <table>
          <thead>
            <tr>
              <th style="width: 40px;" class="center">क्र.</th>
              <th>ग्राहक का नाम</th>
              <th>पता / मकान सं.</th>
              <th>समाचार पत्र</th>
              <th style="width: 60px;" class="center">वितरण</th>
            </tr>
          </thead>
          <tbody>
            ${custs.map((c, i) => {
              const isVacation = store.vacations.some(v => v.customerId == c.id && v.fromDate <= today && v.toDate >= today);
              const papers = (c.papers || []).map(cp => {
                const p = store.newspapers.find(np => np.id == cp.paperId);
                return p ? `${p.name} (${cp.copies})` : '';
              }).join(', ');

              return `
                <tr style="${isVacation ? 'background-color: #ffe6e6;' : ''}">
                  <td class="center">${i + 1}</td>
                  <td><b>${c.name}</b></td>
                  <td>${c.address}</td>
                  <td>${isVacation ? '<b style="color: red;">[छुट्टी - बंद रखें]</b>' : papers}</td>
                  <td class="center">${isVacation ? '❌' : '⬜'}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => { printWin.print(); }, 250);
  },

  // ================= VACATIONS / PAUSE =================
  getVacationsHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">🏖️ छुट्टी एवं रोक प्रबंधन (Vacation & Pause)</h2>
            <p class="text-xs text-slate-500">छुट्टियों की तारीखें और कारण कभी भी एडिट करें</p>
          </div>
          <button onclick="App.openAddVacationModal()" class="touch-btn bg-purple-600 hover:bg-purple-700 text-white font-bold px-4 py-2.5 rounded-xl shadow transition text-sm">
            ➕ नई छुट्टी दर्ज करें
          </button>
        </div>

        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow">
          <h3 class="font-bold text-base text-slate-800 mb-3">दर्ज छुट्टियों की सूची (Edit / Delete)</h3>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-semibold text-xs border-y border-slate-200">
                  <th class="py-3 px-3">ग्राहक</th>
                  <th class="py-3 px-3">कब से (From)</th>
                  <th class="py-3 px-3">कब तक (To)</th>
                  <th class="py-3 px-3">कारण</th>
                  <th class="py-3 px-3 text-center">कार्रवाई</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 font-medium">
                ${store.vacations.map(v => {
                  const cust = store.customers.find(c => c.id == v.customerId) || { name: 'अज्ञात' };
                  return `
                    <tr class="hover:bg-slate-50 transition">
                      <td class="py-3 px-3 font-bold text-slate-800">${cust.name}</td>
                      <td class="py-3 px-3 text-slate-600 text-xs">${v.fromDate}</td>
                      <td class="py-3 px-3 text-slate-600 text-xs">${v.toDate}</td>
                      <td class="py-3 px-3 text-slate-500 text-xs">${v.reason || 'निजी कार्य'}</td>
                      <td class="py-3 px-3 text-center">
                        <div class="flex items-center justify-center gap-2">
                          <button onclick="App.openEditVacationModal(${v.id})" class="text-blue-600 hover:text-blue-800 text-xs font-bold">
                            ✏️ एडिट
                          </button>
                          <button onclick="App.deleteVacation(${v.id})" class="text-red-500 hover:text-red-700 text-xs font-semibold">
                            🗑️ हटाएं
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  openAddVacationModal() {
    this.openVacationFormModal(null);
  },

  openEditVacationModal(id) {
    const v = store.vacations.find(vac => vac.id == id);
    if (!v) return;
    this.openVacationFormModal(v);
  },

  openVacationFormModal(vac = null) {
    const isEdit = !!vac;
    const today = new Date().toISOString().slice(0, 10);
    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 class="text-lg font-black text-slate-800">${isEdit ? '✏️ छुट्टी संपादित करें' : '🏖️ छुट्टी / रोक दर्ज करें'}</h3>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="vacationForm" class="space-y-3.5 text-sm">
            <input type="hidden" id="vacFormId" value="${isEdit ? vac.id : ''}">

            <div>
              <label class="block font-semibold text-slate-700 mb-1">ग्राहक चुनें *</label>
              <select id="vacCustSelect" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                <option value="">-- ग्राहक का नाम चुनें --</option>
                ${store.customers.map(c => `
                  <option value="${c.id}" ${isEdit && vac.customerId == c.id ? 'selected' : ''}>
                    ${c.name} (${c.address})
                  </option>
                `).join('')}
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">कब से (From) *</label>
                <input type="date" id="vacFromDate" value="${isEdit ? vac.fromDate : today}" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">कब तक (To) *</label>
                <input type="date" id="vacToDate" value="${isEdit ? vac.toDate : today}" required class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500">
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">कारण</label>
              <input type="text" id="vacReason" value="${isEdit ? (vac.reason || '') : ''}" placeholder="उदा. गाँव गए हैं / शादी में बाहर हैं" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500">
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button type="button" class="modal-close-btn px-4 py-2.5 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl transition">रद्द करें</button>
              <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition">
                सुरक्षित करें
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('vacationForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const vId = document.getElementById('vacFormId').value;
      const customerId = parseInt(document.getElementById('vacCustSelect').value);
      const fromDate = document.getElementById('vacFromDate').value;
      const toDate = document.getElementById('vacToDate').value;
      const reason = document.getElementById('vacReason').value.trim();

      if (fromDate > toDate) {
        alert("शुरुआत की तारीख समाप्ति की तारीख से पहले होनी चाहिए!");
        return;
      }

      if (vId) {
        const idx = store.vacations.findIndex(v => v.id == vId);
        if (idx !== -1) {
          store.vacations[idx] = { ...store.vacations[idx], customerId, fromDate, toDate, reason };
          store.save('vacations', store.vacations);
          this.showToast("छुट्टी विवरण अपडेट किया गया!");
        }
      } else {
        const newVac = {
          id: Date.now(),
          customerId,
          fromDate,
          toDate,
          reason,
          status: 'active'
        };
        store.vacations.push(newVac);
        store.save('vacations', store.vacations);
        this.showToast("छुट्टी दर्ज की गई!");
      }

      this.closeAllModals();
      this.renderTab('vacations');
    });
  },

  deleteVacation(id) {
    if (confirm("क्या आप इस छुट्टी को हटाना चाहते हैं?")) {
      store.vacations = store.vacations.filter(v => v.id != id);
      store.save('vacations', store.vacations);
      this.showToast("छुट्टी हटा दी गई।");
      this.renderTab('vacations');
    }
  },

  // ================= NEWSPAPERS MASTER (WITH DAY-WISE RATES EDIT) =================
  getNewspapersHTML() {
    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">📰 अख़बार व 7 दिनों की दर सूची (Day-Wise Rates)</h2>
            <p class="text-xs text-slate-500">सप्ताह के किसी भी दिन (उदा. बुधवार विशेषांक या रविवार) की अलग दर सेट करें</p>
          </div>
          <button onclick="App.openAddNewspaperModal()" class="touch-btn bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl shadow transition text-sm">
            ➕ नया अख़बार जोड़ें
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          ${store.newspapers.map(np => {
            const rates = np.ratesByDay || { 0: 6, 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5 };

            return `
              <div class="bg-white p-5 rounded-2xl border border-slate-100 card-shadow space-y-4 flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-md">${np.language}</span>
                    <span class="text-xs text-slate-400">ID: ${np.id}</span>
                  </div>
                  
                  <h3 class="text-xl font-bold text-slate-800 mt-2">${np.name}</h3>
                  <p class="text-xs text-slate-500 mt-0.5">प्रेस खरीद मूल्य: <b>₹${(np.pressCost || 3.5).toFixed(2)}</b></p>

                  <!-- 7-Day Rates Grid -->
                  <div class="mt-4 pt-3 border-t border-slate-100">
                    <div class="text-xs font-bold text-slate-700 mb-2 flex items-center justify-between">
                      <span>📅 सप्ताह के 7 दिनों की दरें:</span>
                      <button onclick="App.openEditNewspaperModal(${np.id})" class="text-blue-600 text-[11px] hover:underline">
                        ✏️ दरें बदलें
                      </button>
                    </div>

                    <div class="grid grid-cols-4 gap-1.5 text-xs text-center font-medium">
                      <!-- 7 days chips -->
                      <div class="bg-red-50 border border-red-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-red-600 font-bold block">रवि</span>
                        <span class="font-black text-red-900 text-sm">₹${rates[0] || np.dailyRate}</span>
                      </div>
                      <div class="bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-slate-500 block">सोम</span>
                        <span class="font-bold text-slate-800 text-sm">₹${rates[1] || np.dailyRate}</span>
                      </div>
                      <div class="bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-slate-500 block">मंगल</span>
                        <span class="font-bold text-slate-800 text-sm">₹${rates[2] || np.dailyRate}</span>
                      </div>
                      <div class="bg-amber-50 border border-amber-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-amber-700 font-bold block">बुध</span>
                        <span class="font-black text-amber-900 text-sm">₹${rates[3] || np.dailyRate}</span>
                      </div>
                      <div class="bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-slate-500 block">गुरु</span>
                        <span class="font-bold text-slate-800 text-sm">₹${rates[4] || np.dailyRate}</span>
                      </div>
                      <div class="bg-slate-50 border border-slate-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-slate-500 block">शुक्र</span>
                        <span class="font-bold text-slate-800 text-sm">₹${rates[5] || np.dailyRate}</span>
                      </div>
                      <div class="bg-blue-50 border border-blue-200 p-1.5 rounded-xl">
                        <span class="text-[10px] text-blue-700 font-bold block">शनि</span>
                        <span class="font-black text-blue-900 text-sm">₹${rates[6] || np.dailyRate}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="pt-3 flex items-center justify-between border-t border-slate-100">
                  <button onclick="App.deleteNewspaper(${np.id})" class="text-red-500 hover:text-red-700 text-xs font-semibold">
                    🗑️ हटाएं
                  </button>
                  <button onclick="App.openEditNewspaperModal(${np.id})" class="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition">
                    ✏️ दरें व नाम एडिट करें
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  },

  openAddNewspaperModal() {
    this.openNewspaperFormModal(null);
  },

  openEditNewspaperModal(id) {
    const paper = store.newspapers.find(p => p.id == id);
    if (!paper) return;
    this.openNewspaperFormModal(paper);
  },

  openNewspaperFormModal(paper = null) {
    const isEdit = !!paper;
    const rates = (paper && paper.ratesByDay) ? paper.ratesByDay : { 0: 7.0, 1: 5.0, 2: 5.0, 3: 6.0, 4: 5.0, 5: 5.0, 6: 6.0 };

    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 card-shadow modal-content space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 class="text-lg font-black text-slate-800">
                ${isEdit ? '✏️ अख़बार एवं 7 दिनों की दरें एडिट करें' : '➕ नया अख़बार जोड़ें'}
              </h3>
              <p class="text-xs text-slate-500">जिस दिन अलग दर (जैसे बुधवार या रविवार) हो, उस दिन की दर यहाँ सेट करें</p>
            </div>
            <button class="modal-close-btn text-slate-400 hover:text-slate-600 text-xl font-bold">✕</button>
          </div>

          <form id="npForm" class="space-y-4 text-sm">
            <input type="hidden" id="npFormId" value="${isEdit ? paper.id : ''}">

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">अख़बार का नाम *</label>
                <input type="text" id="npFormName" required value="${isEdit ? paper.name : ''}" placeholder="उदा. दैनिक भास्कर" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">भाषा</label>
                <input type="text" id="npFormLang" value="${isEdit ? paper.language : 'हिन्दी'}" placeholder="उदा. हिन्दी / English" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">प्रेस खरीद मूल्य (₹ Press Purchase Cost) *</label>
              <input type="number" step="0.1" id="npFormCost" required value="${isEdit ? paper.pressCost : '3.5'}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl font-bold text-slate-700">
            </div>

            <!-- Weekly Day-wise Rates Section -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
              <div class="flex items-center justify-between">
                <span class="font-bold text-slate-800 text-xs sm:text-sm">📅 सप्ताह के 7 दिनों की अलग-अलग दरें (₹)</span>
                <button type="button" onclick="App.autoFillDailyRates()" class="text-[11px] font-bold text-blue-600 hover:underline">
                  सोमवार की दर सभी दिनों में भरें
                </button>
              </div>

              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label class="block text-[11px] font-bold text-red-600 mb-1">रविवार (Sun)</label>
                  <input type="number" step="0.5" id="rate_day_0" required value="${rates[0] || 7.0}" class="w-full px-2 py-2 border border-red-200 rounded-xl text-center font-black text-red-700 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-semibold text-slate-700 mb-1">सोमवार (Mon)</label>
                  <input type="number" step="0.5" id="rate_day_1" required value="${rates[1] || 5.0}" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-center font-bold text-slate-800 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-semibold text-slate-700 mb-1">मंगलवार (Tue)</label>
                  <input type="number" step="0.5" id="rate_day_2" required value="${rates[2] || 5.0}" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-center font-bold text-slate-800 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-bold text-amber-700 mb-1">बुधवार (Wed)</label>
                  <input type="number" step="0.5" id="rate_day_3" required value="${rates[3] || 6.0}" class="w-full px-2 py-2 border border-amber-200 rounded-xl text-center font-black text-amber-800 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-semibold text-slate-700 mb-1">गुरुवार (Thu)</label>
                  <input type="number" step="0.5" id="rate_day_4" required value="${rates[4] || 5.0}" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-center font-bold text-slate-800 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-semibold text-slate-700 mb-1">शुक्रवार (Fri)</label>
                  <input type="number" step="0.5" id="rate_day_5" required value="${rates[5] || 5.0}" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-center font-bold text-slate-800 bg-white">
                </div>
                <div>
                  <label class="block text-[11px] font-bold text-blue-700 mb-1">शनिवार (Sat)</label>
                  <input type="number" step="0.5" id="rate_day_6" required value="${rates[6] || 6.0}" class="w-full px-2 py-2 border border-blue-200 rounded-xl text-center font-black text-blue-800 bg-white">
                </div>
              </div>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
              <button type="button" class="modal-close-btn px-4 py-2.5 text-slate-600 font-semibold text-sm hover:bg-slate-100 rounded-xl transition">रद्द करें</button>
              <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition">
                सुरक्षित करें
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.openModal(html);

    document.getElementById('npForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const id = document.getElementById('npFormId').value;
      const name = document.getElementById('npFormName').value.trim();
      const language = document.getElementById('npFormLang').value.trim();
      const pressCost = parseFloat(document.getElementById('npFormCost').value) || 3.5;

      const newRates = {
        0: parseFloat(document.getElementById('rate_day_0').value) || 5,
        1: parseFloat(document.getElementById('rate_day_1').value) || 5,
        2: parseFloat(document.getElementById('rate_day_2').value) || 5,
        3: parseFloat(document.getElementById('rate_day_3').value) || 5,
        4: parseFloat(document.getElementById('rate_day_4').value) || 5,
        5: parseFloat(document.getElementById('rate_day_5').value) || 5,
        6: parseFloat(document.getElementById('rate_day_6').value) || 5
      };

      const dailyRate = newRates[1]; // Mon rate as standard daily rate

      if (id) {
        const idx = store.newspapers.findIndex(p => p.id == id);
        if (idx !== -1) {
          store.newspapers[idx] = {
            ...store.newspapers[idx],
            name,
            language,
            pressCost,
            dailyRate,
            ratesByDay: newRates
          };
          store.save('newspapers', store.newspapers);
          this.showToast("अख़बार एवं 7 दिनों की दरें अपडेट की गईं!");
        }
      } else {
        const newP = {
          id: Date.now(),
          name,
          language,
          pressCost,
          dailyRate,
          ratesByDay: newRates
        };
        store.newspapers.push(newP);
        store.save('newspapers', store.newspapers);
        this.showToast("नया अख़बार सफलतापूर्वक जोड़ा गया!");
      }

      this.closeAllModals();
      this.renderTab('newspapers');
    });
  },

  autoFillDailyRates() {
    const monRate = document.getElementById('rate_day_1').value;
    if (!monRate) return;
    for (let i = 2; i <= 6; i++) {
      const el = document.getElementById(`rate_day_${i}`);
      if (el) el.value = monRate;
    }
    this.showToast("सोमवार की दर मंगलवार से शनिवार में भर दी गई।", "info");
  },

  deleteNewspaper(id) {
    if (confirm("क्या आप इस अख़बार को हटाना चाहते हैं?")) {
      store.newspapers = store.newspapers.filter(p => p.id != id);
      store.save('newspapers', store.newspapers);
      this.showToast("अख़बार हटा दिया गया।");
      this.renderTab('newspapers');
    }
  },

  // ================= AGENCY PROFILE MODAL & SETTINGS =================
  openEditAgencyModal() {
    this.switchTab('settings');
  },

  getSettingsHTML() {
    return `
      <div class="space-y-6">
        <div class="bg-white p-4 sm:p-6 rounded-2xl border border-slate-100 card-shadow">
          <h2 class="text-xl font-bold text-slate-800 mb-1">⚙️ एजेंसी विवरण संपादित करें (Edit Agency Profile)</h2>
          <p class="text-xs text-slate-500 mb-4">एजेंसी का नाम, मालिक का नाम, फोन और UPI ID कभी भी बदलें</p>

          <form id="agencySettingsForm" class="space-y-4 max-w-lg text-sm">
            <div>
              <label class="block font-semibold text-slate-700 mb-1">एजेंसी का नाम *</label>
              <input type="text" id="setAgencyName" required value="${store.agency.name}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-bold">
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">टैगलाइन / स्लोगन</label>
              <input type="text" id="setTagline" value="${store.agency.tagline || ''}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold text-slate-700 mb-1">वितरक (मालिक) का नाम *</label>
                <input type="text" id="setOwnerName" required value="${store.agency.owner}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
              <div>
                <label class="block font-semibold text-slate-700 mb-1">मोबाइल नंबर *</label>
                <input type="tel" id="setPhone" required value="${store.agency.phone}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
              </div>
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">एजेंसी का पता</label>
              <input type="text" id="setAddress" value="${store.agency.address}" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
              <label class="block font-semibold text-slate-700 mb-1">UPI ID (QR / ऑनलाइन भुगतान हेतु) *</label>
              <input type="text" id="setUpi" required value="${store.agency.upiId}" placeholder="उदा. agency@upi या 9876543210@paytm" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono font-bold text-emerald-700">
            </div>

            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-2.5 rounded-xl transition text-sm">
              विवरण सुरक्षित करें
            </button>
          </form>
        </div>

        <div class="bg-white p-4 sm:p-6 rounded-2xl border border-slate-100 card-shadow space-y-4">
          <h3 class="text-lg font-bold text-slate-800">💾 डेटा बैकअप एवं सुरक्षा (Data Backup)</h3>
          <p class="text-xs text-slate-500">आपका सारा डेटा आपके ब्राउज़र में सुरक्षित है। बैकअप कभी भी डाउनलोड या रीस्टोर करें।</p>

          <div class="flex flex-wrap gap-3">
            <button onclick="App.exportDataBackup()" class="touch-btn bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition flex items-center gap-2">
              <span>📥 बैकअप फ़ाइल डाउनलोड करें (JSON)</span>
            </button>

            <label class="touch-btn bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition flex items-center gap-2 cursor-pointer">
              <span>📤 बैकअप रीस्टोर करें</span>
              <input type="file" id="restoreFileInput" accept=".json" class="hidden">
            </label>

            <button onclick="App.resetToDemoData()" class="touch-btn bg-red-100 hover:bg-red-200 text-red-700 font-bold px-4 py-2.5 rounded-xl text-xs transition ml-auto">
              🔄 डेमो डेटा रीसेट करें
            </button>
          </div>
        </div>
      </div>
    `;
  },

  attachSettingsEvents() {
    const form = document.getElementById('agencySettingsForm');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        store.agency = {
          ...store.agency,
          name: document.getElementById('setAgencyName').value.trim(),
          tagline: document.getElementById('setTagline').value.trim(),
          owner: document.getElementById('setOwnerName').value.trim(),
          phone: document.getElementById('setPhone').value.trim(),
          address: document.getElementById('setAddress').value.trim(),
          upiId: document.getElementById('setUpi').value.trim()
        };
        store.save('agency', store.agency);
        this.renderHeader();
        this.showToast("एजेंसी विवरण अपडेट हो गया!");
      });
    }

    const restoreInput = document.getElementById('restoreFileInput');
    if (restoreInput) {
      restoreInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            const data = JSON.parse(event.target.result);
            if (data.customers && data.newspapers && data.lines) {
              store.save('agency', data.agency || DEFAULT_AGENCY);
              store.save('newspapers', data.newspapers);
              store.save('lines', data.lines);
              store.save('customers', data.customers);
              store.save('vacations', data.vacations || []);
              store.save('payments', data.payments || []);
              store.save('billAdjustments', data.billAdjustments || {});
              store.init();
              this.showToast("बैकअप सफलतापूर्वक रीस्टोर हो गया!");
              this.renderHeader();
              this.renderTab('dashboard');
            } else {
              alert("अमान्य बैकअप फ़ाइल!");
            }
          } catch (err) {
            alert("फ़ाइल पढ़ने में त्रुटि: " + err.message);
          }
        };
        reader.readAsText(file);
      });
    }
  },

  getRequestsHTML() {
    const reqs = JSON.parse(localStorage.getItem('np_customer_requests') || '[]');
    const pendingCount = reqs.filter(r => r.status === 'pending').length;

    return `
      <div class="space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <h2 class="text-xl font-bold text-slate-800">📩 ग्राहकों के अनुरोध (Customer Requests)</h2>
            <p class="text-xs text-slate-500">ग्राहक पोर्टल से आए नए अख़बार एवं सेवाओं के अनुरोध</p>
          </div>
          <a href="customer.html" target="_blank" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-start">
            <span>📱 ग्राहक पोर्टल खोलकर देखें →</span>
          </a>
        </div>

        <div class="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 card-shadow">
          <div class="flex items-center justify-between mb-4">
            <h3 class="font-bold text-slate-800 text-base">अनुरोध सूची (${reqs.length})</h3>
            <span class="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-50 text-amber-700">
              लंबित (Pending): ${pendingCount}
            </span>
          </div>

          ${reqs.length === 0 ? `
            <div class="p-8 text-center text-slate-400">
              <div class="text-4xl mb-2">📭</div>
              <p class="font-medium text-slate-600">अभी तक कोई नया अनुरोध नहीं आया है।</p>
              <p class="text-xs mt-1">ग्राहक अपने मोबाइल से 'ग्राहक पोर्टल' पर जाकर नया अख़बार शुरू कराने का अनुरोध भेज सकते हैं।</p>
            </div>
          ` : `
            <div class="space-y-3">
              ${reqs.map(r => `
                <div class="p-4 rounded-2xl border ${r.status === 'pending' ? 'bg-amber-50/40 border-amber-200' : r.status === 'approved' ? 'bg-emerald-50/40 border-emerald-200' : 'bg-slate-50 border-slate-200'} flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div class="space-y-1">
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-slate-800 text-base">${r.customerName}</span>
                      <span class="text-xs text-slate-500 font-mono">📱 ${r.customerPhone}</span>
                      <span class="text-xs px-2 py-0.5 rounded-md font-bold ${r.status === 'pending' ? 'bg-amber-100 text-amber-800' : r.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}">
                        ${r.status === 'pending' ? 'लंबित (Pending)' : r.status === 'approved' ? 'स्वीकृत (Approved)' : 'अस्वीकृत'}
                      </span>
                    </div>

                    <p class="text-xs text-slate-700">
                      अनुरोध: <b>${r.paperName}</b> (${r.copies} प्रति) | कब से: <b>${r.startDate}</b>
                    </p>
                    ${r.notes ? `<p class="text-xs text-slate-500 italic">नोट: "${r.notes}"</p>` : ''}
                    <p class="text-[11px] text-slate-400">तारीख: ${r.date}</p>
                  </div>

                  <div class="flex items-center gap-2 self-end sm:self-center">
                    ${r.status === 'pending' ? `
                      <button onclick="App.approveCustomerRequest(${r.id})" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition">
                        ✓ स्वीकार करें (Add Paper)
                      </button>
                      <button onclick="App.rejectCustomerRequest(${r.id})" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-semibold transition">
                        ✕ अस्वीकार
                      </button>
                    ` : `
                      <button onclick="App.deleteCustomerRequest(${r.id})" class="text-red-500 hover:text-red-700 text-xs font-semibold p-1">
                        🗑️ हटाएं
                      </button>
                    `}
                  </div>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;
  },

  approveCustomerRequest(reqId) {
    let reqs = JSON.parse(localStorage.getItem('np_customer_requests') || '[]');
    const rIdx = reqs.findIndex(r => r.id == reqId);
    if (rIdx === -1) return;

    const r = reqs[rIdx];
    const custIdx = store.customers.findIndex(c => c.id == r.customerId);

    if (custIdx !== -1) {
      const cust = store.customers[custIdx];
      const papers = cust.papers || [];
      const existingPaper = papers.find(p => p.paperId == r.paperId);

      if (existingPaper) {
        existingPaper.copies += (r.copies || 1);
      } else {
        papers.push({ paperId: r.paperId, copies: r.copies || 1 });
      }

      cust.papers = papers;
      store.save('customers', store.customers);
    }

    reqs[rIdx].status = 'approved';
    localStorage.setItem('np_customer_requests', JSON.stringify(reqs));

    this.showToast("अनुरोध स्वीकार कर लिया गया और ग्राहक के खाते में अख़बार जोड़ दिया गया!");
    this.renderTab('requests');
  },

  rejectCustomerRequest(reqId) {
    let reqs = JSON.parse(localStorage.getItem('np_customer_requests') || '[]');
    const rIdx = reqs.findIndex(r => r.id == reqId);
    if (rIdx !== -1) {
      reqs[rIdx].status = 'rejected';
      localStorage.setItem('np_customer_requests', JSON.stringify(reqs));
      this.showToast("अनुरोध अस्वीकार कर दिया गया।", "info");
      this.renderTab('requests');
    }
  },

  deleteCustomerRequest(reqId) {
    let reqs = JSON.parse(localStorage.getItem('np_customer_requests') || '[]');
    reqs = reqs.filter(r => r.id != reqId);
    localStorage.setItem('np_customer_requests', JSON.stringify(reqs));
    this.showToast("अनुरोध हटा दिया गया।");
    this.renderTab('requests');
  },

  // ================= CUSTOMER CHAT SYSTEM =================
  getChatsHTML() {
    store.chats = store.get('chats', DEFAULT_CHATS);
    const unreadTotal = store.chats.filter(m => m.sender === 'customer' && !m.readByDistributor).length;

    // Group chats by customer
    const custMap = {};
    store.chats.forEach(m => {
      if (!custMap[m.customerId]) {
        const cust = store.customers.find(c => c.id == m.customerId);
        custMap[m.customerId] = {
          customerId: m.customerId,
          customer: cust || { id: m.customerId, name: m.customerName || 'ग्राहक', phone: m.customerPhone || '', currentDue: 0, lineId: 1 },
          lastMessage: m,
          unreadCount: 0
        };
      }
      if (new Date(m.timestamp) > new Date(custMap[m.customerId].lastMessage.timestamp)) {
        custMap[m.customerId].lastMessage = m;
      }
      if (m.sender === 'customer' && !m.readByDistributor) {
        custMap[m.customerId].unreadCount++;
      }
    });

    const conversationList = Object.values(custMap).sort((a, b) => new Date(b.lastMessage.timestamp) - new Date(a.lastMessage.timestamp));

    // Determine active customer id
    if (!this.activeChatCustomerId) {
      if (conversationList.length > 0) {
        this.activeChatCustomerId = conversationList[0].customerId;
      } else if (store.customers.length > 0) {
        this.activeChatCustomerId = store.customers[0].id;
      }
    }

    // Mark current active customer's messages as read
    if (this.activeChatCustomerId) {
      let updated = false;
      store.chats.forEach(m => {
        if (m.customerId == this.activeChatCustomerId && m.sender === 'customer' && !m.readByDistributor) {
          m.readByDistributor = true;
          updated = true;
        }
      });
      if (updated) {
        store.save('chats', store.chats);
        this.updateChatBadges();
      }
    }

    const activeCust = store.customers.find(c => c.id == this.activeChatCustomerId) || (conversationList.find(c => c.customerId == this.activeChatCustomerId)?.customer);
    const activeLine = activeCust ? (store.lines.find(l => l.id == activeCust.lineId) || { name: 'सामान्य लाइन' }) : null;
    const activeMessages = this.activeChatCustomerId ? store.chats.filter(m => m.customerId == this.activeChatCustomerId) : [];
    const activeDue = activeCust ? (parseFloat(activeCust.currentDue) || 0) : 0;
    const cleanPhone = activeCust ? activeCust.phone.replace(/[^0-9]/g, '') : '';
    const phoneWithCode = cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone;

    // Filter conversations by search if any
    const q = (this.chatSearchQuery || '').toLowerCase().trim();
    const filteredConvs = conversationList.filter(item => {
      if (!q) return true;
      return (item.customer.name || '').toLowerCase().includes(q) || (item.customer.phone || '').includes(q);
    });

    return `
      <div class="space-y-4">
        <!-- Top Title Bar -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-100 card-shadow">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-bold text-slate-800">💬 ग्राहक चैट बॉक्स (Live Customer Chats)</h2>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${unreadTotal > 0 ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-100 text-slate-600'}">
                ${unreadTotal > 0 ? `${unreadTotal} नए संदेश` : 'सभी पढ़े हुए'}
              </span>
            </div>
            <p class="text-xs text-slate-500 mt-0.5">ग्राहकों के साथ सीधा संवाद, शिकायतों का समाधान और तुरंत उत्तर दें</p>
          </div>

          <div class="flex items-center gap-2">
            <select id="startNewChatDropdown" onchange="App.handleStartNewChat(this.value)" class="text-xs px-3 py-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl text-blue-800 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer">
              <option value="">➕ किसी अन्य ग्राहक से चैट शुरू करें...</option>
              ${store.customers.map(c => `
                <option value="${c.id}">${c.name} (${c.phone}) - लाइन ${c.lineId || 1}</option>
              `).join('')}
            </select>
          </div>
        </div>

        <!-- Two Column Chat Layout -->
        <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden card-shadow grid grid-cols-1 md:grid-cols-12 min-h-[580px]">
          
          <!-- LEFT COLUMN: Conversation List (4 Cols) -->
          <div class="md:col-span-5 lg:col-span-4 border-r border-slate-200 flex flex-col bg-slate-50/70">
            <!-- Search in chats -->
            <div class="p-3 border-b border-slate-200 bg-white">
              <div class="relative">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-sm">🔍</span>
                <input 
                  type="text" 
                  id="chatSearchInput" 
                  value="${this.chatSearchQuery || ''}" 
                  placeholder="ग्राहक का नाम या फोन खोजें..." 
                  class="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
              </div>
            </div>

            <!-- Conversations List Items -->
            <div class="flex-1 overflow-y-auto divide-y divide-slate-100 max-h-[520px]">
              ${filteredConvs.length === 0 ? `
                <div class="p-8 text-center text-slate-400 space-y-2">
                  <div class="text-3xl">📭</div>
                  <p class="text-xs font-semibold text-slate-600">कोई चैट नहीं मिली</p>
                  <p class="text-[11px] text-slate-400">ऊपर ड्रॉपडाउन से किसी भी ग्राहक का चयन करें।</p>
                </div>
              ` : filteredConvs.map(item => {
                const c = item.customer;
                const isSelected = c.id == this.activeChatCustomerId;
                const line = store.lines.find(l => l.id == c.lineId) || { name: 'लाइन' };
                const last = item.lastMessage;
                const isMe = last.sender === 'distributor';
                const due = parseFloat(c.currentDue) || 0;

                return `
                  <div 
                    onclick="App.selectChatCustomer(${c.id})" 
                    class="p-3.5 cursor-pointer transition flex items-start gap-3 ${
                      isSelected 
                        ? 'bg-blue-50/90 border-l-4 border-blue-600' 
                        : 'hover:bg-slate-100/80 bg-white'
                    }"
                  >
                    <!-- Customer Avatar -->
                    <div class="w-10 h-10 rounded-2xl bg-gradient-to-tr ${
                      isSelected ? 'from-blue-600 to-indigo-600 text-white' : 'from-slate-200 to-slate-300 text-slate-700'
                    } flex items-center justify-center font-bold text-sm flex-shrink-0 shadow-sm">
                      ${c.name ? c.name.charAt(0) : '👤'}
                    </div>

                    <!-- Meta & Snippet -->
                    <div class="flex-1 min-w-0">
                      <div class="flex items-center justify-between gap-1">
                        <span class="font-bold text-xs sm:text-sm text-slate-800 truncate ${item.unreadCount > 0 ? 'font-black' : ''}">
                          ${c.name}
                        </span>
                        <span class="text-[10px] text-slate-400 whitespace-nowrap">
                          ${last.timeStr || ''}
                        </span>
                      </div>

                      <div class="flex items-center gap-1.5 mt-0.5 text-[11px]">
                        <span class="text-slate-400 truncate">
                          📍 ${line.name.split('-')[0]}
                        </span>
                        ${due > 0 ? `<span class="text-red-500 font-semibold">• ₹${due}</span>` : ''}
                      </div>

                      <div class="flex items-center justify-between gap-2 mt-1">
                        <p class="text-xs text-slate-500 truncate ${item.unreadCount > 0 ? 'font-bold text-slate-800' : ''}">
                          ${isMe ? '<span class="text-blue-600">आप: </span>' : ''}${last.text || ''}
                        </p>
                        ${item.unreadCount > 0 ? `
                          <span class="px-2 py-0.5 bg-red-500 text-white font-black text-[10px] rounded-full flex-shrink-0 animate-pulse">
                            ${item.unreadCount}
                          </span>
                        ` : ''}
                      </div>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

          <!-- RIGHT COLUMN: Active Chat Panel (8 Cols) -->
          <div class="md:col-span-7 lg:col-span-8 flex flex-col h-full bg-slate-50/30">
            ${!activeCust ? `
              <div class="my-auto text-center p-8 space-y-3">
                <div class="text-5xl">💬</div>
                <h3 class="text-base font-bold text-slate-700">कोई ग्राहक चैट नहीं चुनी गई</h3>
                <p class="text-xs text-slate-400">बाईं ओर से किसी ग्राहक पर क्लिक करें या नया चैट शुरू करें।</p>
              </div>
            ` : `
              <!-- Active Customer Chat Header -->
              <div class="p-3.5 sm:p-4 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-sm">
                <div class="flex items-center gap-3">
                  <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-700 text-white flex items-center justify-center font-bold text-base shadow">
                    ${activeCust.name ? activeCust.name.charAt(0) : '👤'}
                  </div>
                  <div>
                    <div class="flex items-center gap-2 flex-wrap">
                      <h3 class="font-black text-sm sm:text-base text-slate-800">${activeCust.name}</h3>
                      <span class="text-[11px] px-2 py-0.5 rounded-full font-bold ${activeDue > 0 ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-emerald-50 text-emerald-700'}">
                        ${activeDue > 0 ? `बकाया: ₹${activeDue}` : 'चुकता ✓'}
                      </span>
                    </div>
                    <div class="flex items-center gap-3 text-xs text-slate-500 mt-0.5 flex-wrap">
                      <span>📞 ${activeCust.phone}</span>
                      <span>📍 ${activeLine ? activeLine.name : ''}</span>
                    </div>
                  </div>
                </div>

                <!-- Header Actions -->
                <div class="flex items-center gap-1.5 flex-wrap">
                  <a href="tel:${cleanPhone}" class="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition" title="कॉल करें">
                    📞 कॉल
                  </a>
                  <a href="https://wa.me/${phoneWithCode}?text=${encodeURIComponent(`नमस्ते ${activeCust.name} जी, श्री गणेश न्यूज़पेपर एजेंसी की ओर से संदेश:`)}" target="_blank" class="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-bold transition" title="WhatsApp पर खोलें">
                    📲 WhatsApp
                  </a>
                  <button onclick="App.openCustomerLedgerModal(${activeCust.id})" class="p-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-bold transition" title="खाता-बही देखें">
                    🧾 खाता
                  </button>
                  <button onclick="App.openRecordPaymentModal(${activeCust.id})" class="p-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold transition" title="भुगतान दर्ज करें">
                    ₹ पेमेंट
                  </button>
                </div>
              </div>

              <!-- Message Stream Box -->
              <div id="distChatMessagesBox" class="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-100/60 max-h-[380px] min-h-[340px]">
                ${activeMessages.length === 0 ? `
                  <div class="my-auto text-center py-12 space-y-2">
                    <div class="text-4xl">📝</div>
                    <p class="font-bold text-slate-700 text-sm">इस ग्राहक के साथ अभी कोई संदेश नहीं है</p>
                    <p class="text-xs text-slate-400">नीचे त्वरित उत्तर (Templates) पर क्लिक करें या सीधे संदेश लिखकर भेजें।</p>
                  </div>
                ` : activeMessages.map(m => {
                  const isMe = m.sender === 'distributor';
                  const isFeedback = m.text.includes('⭐') || m.text.includes('फीडबैक');
                  return `
                    <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1">
                      <span class="text-[10px] text-slate-400 font-semibold px-1 flex items-center gap-1">
                        ${isMe ? 'आप (वितरक)' : '👤 ' + (m.customerName || activeCust.name)}
                        ${isFeedback ? '<span class="text-amber-500 font-bold">⭐ ग्राहक रिव्यू</span>' : ''}
                      </span>
                      <div class="max-w-[85%] p-3.5 rounded-2xl shadow-sm text-xs break-words leading-relaxed ${
                        isMe 
                          ? 'bg-blue-600 text-white rounded-tr-none font-medium' 
                          : isFeedback
                            ? 'bg-gradient-to-r from-amber-50 to-orange-50 text-slate-800 border-2 border-amber-300 rounded-tl-none font-medium'
                            : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none font-medium'
                      }">
                        ${isFeedback ? '<div class="text-[11px] font-black text-amber-700 flex items-center gap-1 mb-1"><span>⭐</span><span>ग्राहक फीडबैक एवं रेटिंग</span></div>' : ''}
                        <p class="whitespace-pre-wrap">${this.escapeHTML(m.text)}</p>
                      </div>
                      <div class="flex items-center gap-1 text-[10px] text-slate-400 px-1">
                        <span>${m.timeStr || ''}</span>
                        ${isMe ? '<span class="text-blue-600 font-bold">✓✓</span>' : ''}
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>

              <!-- Quick Reply Templates for Distributor -->
              <div class="px-3 pt-2 bg-white border-t border-slate-100">
                <div class="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex-shrink-0">⚡ त्वरित उत्तर:</span>
                  <button type="button" onclick="App.sendDistQuickTemplate('आपके बहुमूल्य फीडबैक एवं रेटिंग के लिए बहुत-बहुत धन्यवाद! ⭐')" class="whitespace-nowrap px-2.5 py-1 bg-amber-50 text-amber-800 font-bold hover:bg-amber-100 rounded-lg text-[11px] transition flex-shrink-0">
                    ⭐ फीडबैक का धन्यवाद दें
                  </button>
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex-shrink-0">⚡ त्वरित उत्तर:</span>
                  <button type="button" onclick="App.sendDistQuickTemplate('नमस्ते! जी बिल्कुल, हॉकर को बोल दिया है, कल सुबह समय पर मिल जाएगा।')" class="whitespace-nowrap px-2.5 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 rounded-lg text-slate-700 text-[11px] font-medium transition flex-shrink-0">
                    👍 हाँ, कल सुबह चालू हो जाएगा
                  </button>
                  <button type="button" onclick="App.sendDistQuickTemplate('आपका भुगतान प्राप्त हो गया है, हिसाब अपडेट कर दिया गया है। धन्यवाद!')" class="whitespace-nowrap px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 rounded-lg text-slate-700 text-[11px] font-medium transition flex-shrink-0">
                    💰 भुगतान मिल गया, धन्यवाद!
                  </button>
                  <button type="button" onclick="App.sendDistQuickTemplate('हॉकर रास्ते में है, बस 10-15 मिनट में आपके पते पर पहुँच रहा है।')" class="whitespace-nowrap px-2.5 py-1 bg-slate-100 hover:bg-amber-50 hover:text-amber-700 rounded-lg text-slate-700 text-[11px] font-medium transition flex-shrink-0">
                    🚴‍♂️ हॉकर 10-15 मिनट में आ रहा है
                  </button>
                  <button type="button" onclick="App.sendDistQuickTemplate('नमस्ते ${activeCust.name} जी, आपका कुल बकाया बिल ₹' + (${activeDue}) + ' है। कृपया ऑनलाइन भुगतान करें।')" class="whitespace-nowrap px-2.5 py-1 bg-slate-100 hover:bg-red-50 hover:text-red-700 rounded-lg text-slate-700 text-[11px] font-medium transition flex-shrink-0">
                    🧾 बकाया बिल का रिमाइंडर
                  </button>
                  <button type="button" onclick="App.sendDistQuickTemplate('आपकी छुट्टी की सूचना दर्ज कर ली गई है, उन दिनों का बिल में से पैसा कट जाएगा।')" class="whitespace-nowrap px-2.5 py-1 bg-slate-100 hover:bg-purple-50 hover:text-purple-700 rounded-lg text-slate-700 text-[11px] font-medium transition flex-shrink-0">
                    🏖️ छुट्टी दर्ज कर ली गई है
                  </button>
                </div>
              </div>

              <!-- Input Form for Distributor -->
              <form id="distSendMessageForm" class="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
                <input 
                  type="text" 
                  id="distChatInput" 
                  placeholder="यहाँ ग्राहक के लिए उत्तर लिखें..." 
                  autocomplete="off" 
                  required
                  class="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                <button 
                  type="submit" 
                  class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5 text-xs sm:text-sm flex-shrink-0"
                >
                  <span>उत्तर भेजें</span>
                  <span>🚀</span>
                </button>
              </form>
            `}
          </div>
        </div>
      </div>
    `;
  },

  attachChatEvents() {
    const searchInput = document.getElementById('chatSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.chatSearchQuery = e.target.value;
        this.renderTab('chats');
        const refreshedInput = document.getElementById('chatSearchInput');
        if (refreshedInput) {
          refreshedInput.focus();
          refreshedInput.setSelectionRange(refreshedInput.value.length, refreshedInput.value.length);
        }
      });
    }

    const form = document.getElementById('distSendMessageForm');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const input = document.getElementById('distChatInput');
        const text = input ? input.value.trim() : '';
        if (!text) return;
        this.sendDistributorReply(text);
        if (input) input.value = '';
      });
    }

    this.scrollDistChatToBottom();
  },

  selectChatCustomer(custId) {
    this.activeChatCustomerId = custId;
    this.renderTab('chats');
    this.attachChatEvents();
  },

  handleStartNewChat(custId) {
    if (!custId) return;
    this.activeChatCustomerId = parseInt(custId);
    this.renderTab('chats');
    this.attachChatEvents();
  },

  sendDistQuickTemplate(text) {
    this.sendDistributorReply(text);
  },

  sendDistributorReply(text) {
    if (!this.activeChatCustomerId) return;
    const cust = store.customers.find(c => c.id == this.activeChatCustomerId);
    store.chats = store.get('chats', DEFAULT_CHATS);

    const now = new Date();
    const timeStr = now.toLocaleTimeString('hi-IN', { hour: '2-digit', minute: '2-digit' });

    const newMsg = {
      id: 'msg_' + Date.now(),
      customerId: this.activeChatCustomerId,
      customerName: cust ? cust.name : 'ग्राहक',
      customerPhone: cust ? cust.phone : '',
      sender: 'distributor',
      text: text,
      timestamp: now.toISOString(),
      timeStr: timeStr,
      readByDistributor: true,
      readByCustomer: false
    };

    store.chats.push(newMsg);
    store.save('chats', store.chats);

    this.renderTab('chats');
    this.attachChatEvents();
    this.updateChatBadges();
    this.showToast("ग्राहक को उत्तर भेज दिया गया! 🚀");
  },

  refreshDistChatIfOpen() {
    const box = document.getElementById('distChatMessagesBox');
    if (!box || !this.activeChatCustomerId) return;
    const isAtBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;

    store.chats = store.get('chats', DEFAULT_CHATS);
    const activeMessages = store.chats.filter(m => m.customerId == this.activeChatCustomerId);
    const activeCust = store.customers.find(c => c.id == this.activeChatCustomerId);

    // Mark as read
    let updated = false;
    store.chats.forEach(m => {
      if (m.customerId == this.activeChatCustomerId && m.sender === 'customer' && !m.readByDistributor) {
        m.readByDistributor = true;
        updated = true;
      }
    });
    if (updated) {
      store.save('chats', store.chats);
    }

    if (activeMessages.length === 0) {
      box.innerHTML = `
        <div class="my-auto text-center py-12 space-y-2">
          <div class="text-4xl">📝</div>
          <p class="font-bold text-slate-700 text-sm">इस ग्राहक के साथ अभी कोई संदेश नहीं है</p>
          <p class="text-xs text-slate-400">नीचे त्वरित उत्तर (Templates) पर क्लिक करें या सीधे संदेश लिखकर भेजें।</p>
        </div>
      `;
    } else {
      box.innerHTML = activeMessages.map(m => {
        const isMe = m.sender === 'distributor';
        const isFeedback = m.text.includes('⭐') || m.text.includes('फीडबैक');
        return `
          <div class="flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1">
            <span class="text-[10px] text-slate-400 font-semibold px-1 flex items-center gap-1">
              ${isMe ? 'आप (वितरक)' : '👤 ' + (m.customerName || (activeCust ? activeCust.name : 'ग्राहक'))}
              ${isFeedback ? '<span class="text-amber-500 font-bold">⭐ ग्राहक रिव्यू</span>' : ''}
            </span>
            <div class="max-w-[85%] p-3.5 rounded-2xl shadow-sm text-xs break-words leading-relaxed ${
              isMe 
                ? 'bg-blue-600 text-white rounded-tr-none font-medium' 
                : isFeedback
                  ? 'bg-gradient-to-r from-amber-50 to-orange-50 text-slate-800 border-2 border-amber-300 rounded-tl-none font-medium'
                  : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none font-medium'
            }">
              ${isFeedback ? '<div class="text-[11px] font-black text-amber-700 flex items-center gap-1 mb-1"><span>⭐</span><span>ग्राहक फीडबैक एवं रेटिंग</span></div>' : ''}
              <p class="whitespace-pre-wrap">${this.escapeHTML(m.text)}</p>
            </div>
            <div class="flex items-center gap-1 text-[10px] text-slate-400 px-1">
              <span>${m.timeStr || ''}</span>
              ${isMe ? '<span class="text-blue-600 font-bold">✓✓</span>' : ''}
            </div>
          </div>
        `;
      }).join('');
    }

    if (isAtBottom) {
      this.scrollDistChatToBottom();
    }
  },

  scrollDistChatToBottom() {
    const box = document.getElementById('distChatMessagesBox');
    if (box) {
      box.scrollTop = box.scrollHeight;
    }
  },

  updateChatBadges() {
    store.chats = store.get('chats', DEFAULT_CHATS);
    const unread = store.chats.filter(m => m.sender === 'customer' && !m.readByDistributor).length;

    const desktopBadge = document.getElementById('distChatBadgeDesktop');
    if (desktopBadge) {
      if (unread > 0) {
        desktopBadge.textContent = unread;
        desktopBadge.classList.remove('hidden');
      } else {
        desktopBadge.classList.add('hidden');
      }
    }

    const mobileBadge = document.getElementById('distChatBadgeMobile');
    if (mobileBadge) {
      mobileBadge.classList.toggle('hidden', unread === 0);
    }

    const headerBadge = document.getElementById('headerNotifBadge');
    if (headerBadge) {
      if (unread > 0) {
        headerBadge.textContent = unread;
        headerBadge.classList.remove('hidden');
      } else {
        headerBadge.classList.add('hidden');
      }
    }
  },

  checkForIncomingMessages() {
    const freshChats = store.get('chats', DEFAULT_CHATS);

    // Look for new customer messages
    if (freshChats.length > 0) {
      const latest = freshChats[freshChats.length - 1];
      if (this.lastKnownMessageId && latest.id !== this.lastKnownMessageId) {
        this.lastKnownMessageId = latest.id;
        if (latest.sender === 'customer') {
          this.triggerNewMessageNotification(latest);
        }
      } else if (!this.lastKnownMessageId) {
        this.lastKnownMessageId = latest.id;
      }
    }

    store.chats = freshChats;
    this.updateChatBadges();
    if (this.currentTab === 'chats') {
      this.refreshDistChatIfOpen();
    }
  },

  triggerNewMessageNotification(msg) {
    // 1. Play pleasant audio alert chime
    if (this.soundEnabled) {
      this.playNotificationSound();
    }

    // 2. Desktop Push Notification (Windows Notification Center)
    if ('Notification' in window && Notification.permission === 'granted') {
      const isFeedback = msg.text.includes('फीडबैक') || msg.text.includes('स्टार') || msg.text.includes('⭐');
      const title = isFeedback ? `⭐ नया ग्राहक फीडबैक: ${msg.customerName}` : `🔔 नया संदेश: ${msg.customerName}`;
      try {
        const notif = new Notification(title, {
          body: msg.text,
          icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">📰</text></svg>'
        });
        notif.onclick = () => {
          window.focus();
          App.openCustomerChat(msg.customerId);
        };
      } catch (e) {
        console.log("Desktop notification error", e);
      }
    }

    // 3. Eye-catching In-App Floating Alert Banner (Top Right)
    this.showFloatingNotificationBanner(msg);
  },

  playNotificationSound() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Two-note ascending chime: D5 (587Hz) -> A5 (880Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now);
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.15);
      gain1.gain.setValueAtTime(0.35, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.55);

      // Harmonizing high bell tone
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(880, now + 0.1);
      osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.25);
      gain2.gain.setValueAtTime(0.2, now + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.1);
      osc2.stop(now + 0.65);
    } catch (e) {
      console.log("Audio alert error", e);
    }
  },

  showFloatingNotificationBanner(msg) {
    const existing = document.getElementById('floatingNewMsgAlert');
    if (existing) existing.remove();

    const isFeedback = msg.text.includes('फीडबैक') || msg.text.includes('स्टार') || msg.text.includes('⭐');
    const banner = document.createElement('div');
    banner.id = 'floatingNewMsgAlert';
    banner.className = 'fixed top-5 right-5 z-50 max-w-sm w-full bg-white border-2 border-amber-400 rounded-3xl shadow-2xl p-4 toast-animate flex items-start gap-3';
    banner.innerHTML = `
      <div class="w-11 h-11 rounded-2xl ${isFeedback ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'} flex items-center justify-center text-2xl flex-shrink-0 animate-bounce">
        ${isFeedback ? '⭐' : '🔔'}
      </div>
      <div class="flex-1 min-w-0">
        <div class="flex items-center justify-between">
          <span class="text-[11px] font-black uppercase tracking-wider ${isFeedback ? 'text-amber-700' : 'text-blue-700'}">
            ${isFeedback ? '⭐ नया ग्राहक फीडबैक!' : '🔔 नया ग्राहक संदेश!'}
          </span>
          <button onclick="document.getElementById('floatingNewMsgAlert')?.remove()" class="text-slate-400 hover:text-slate-600 text-sm font-bold">✕</button>
        </div>
        <p class="font-extrabold text-slate-800 text-sm mt-0.5 truncate">${this.escapeHTML(msg.customerName || 'ग्राहक')}</p>
        <p class="text-xs text-slate-600 mt-0.5 line-clamp-2 leading-relaxed">${this.escapeHTML(msg.text)}</p>
        <div class="mt-2.5 flex items-center gap-2">
          <button onclick="App.openCustomerChat(${msg.customerId}); document.getElementById('floatingNewMsgAlert')?.remove();" class="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1">
            <span>जवाब दें / देखें 💬</span>
          </button>
          <button onclick="document.getElementById('floatingNewMsgAlert')?.remove()" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold text-xs rounded-xl transition">
            हटाएं
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(banner);

    setTimeout(() => {
      if (banner && banner.parentNode) {
        banner.remove();
      }
    }, 9000);
  },

  requestNotificationPermissionOnce() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  },

  toggleNotificationSettingsModal() {
    const isGranted = 'Notification' in window && Notification.permission === 'granted';
    const html = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay bg-black/60 backdrop-blur-sm">
        <div class="bg-white rounded-3xl max-w-sm w-full p-6 card-shadow modal-content space-y-4 text-center">
          <div class="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-3xl mx-auto shadow-inner">
            🔔
          </div>
          <div>
            <h3 class="font-black text-slate-800 text-base">नोटिफिकेशन एवं अलर्ट सेटिंग्स</h3>
            <p class="text-xs text-slate-500 mt-1">जब भी कोई ग्राहक संदेश या फीडबैक भेजेगा, आपको तुरंत सूचना मिलेगी।</p>
          </div>

          <div class="space-y-2.5 text-left text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div class="flex items-center justify-between">
              <div>
                <p class="font-bold text-slate-800">🔊 घंटी की आवाज़ (Audio Chime)</p>
                <p class="text-[11px] text-slate-500">संदेश आने पर बीप/घंटी बजेगी</p>
              </div>
              <button onclick="App.soundEnabled = !App.soundEnabled; App.playNotificationSound(); this.textContent = App.soundEnabled ? 'चालू ✓' : 'बंद ✕'; this.className = App.soundEnabled ? 'px-2.5 py-1 bg-emerald-600 text-white font-bold rounded-lg text-xs' : 'px-2.5 py-1 bg-slate-300 text-slate-700 font-bold rounded-lg text-xs';" class="${this.soundEnabled ? 'px-2.5 py-1 bg-emerald-600 text-white font-bold rounded-lg text-xs' : 'px-2.5 py-1 bg-slate-300 text-slate-700 font-bold rounded-lg text-xs'}">
                ${this.soundEnabled ? 'चालू ✓' : 'बंद ✕'}
              </button>
            </div>

            <div class="border-t border-slate-200 pt-2 flex items-center justify-between">
              <div>
                <p class="font-bold text-slate-800">🖥️ डेस्कटॉप पॉप-अप अलर्ट</p>
                <p class="text-[11px] text-slate-500">${isGranted ? 'विंडोज नोटिफिकेशन सक्रिय है' : 'ब्राउज़र अनुमति आवश्यक है'}</p>
              </div>
              <button onclick="App.enableDesktopNotifications();" class="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs">
                ${isGranted ? 'सक्रिय है ✓' : 'चालू करें'}
              </button>
            </div>
          </div>

          <button onclick="App.playNotificationSound(); App.showToast('घंटी का परीक्षण सफल! 🔔');" class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5">
            <span>🔔 टेस्ट घंटी बजाएं (Test Sound)</span>
          </button>

          <button onclick="App.closeAllModals()" class="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow transition">
            ठीक है (बंद करें)
          </button>
        </div>
      </div>
    `;
    this.openModal(html);
  },

  enableDesktopNotifications() {
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          this.playNotificationSound();
          new Notification("🔔 श्री गणेश न्यूज़पेपर एजेंसी", {
            body: "नोटिफिकेशन सक्रिय हो गया है! नया ग्राहक संदेश आते ही यहाँ सूचना दिखेगी।",
            icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">📰</text></svg>'
          });
          this.showToast("डेस्कटॉप नोटिफिकेशन सक्रिय हो गया! 🔔");
          this.closeAllModals();
        } else {
          this.showToast("ब्राउज़र द्वारा नोटिफिकेशन अस्वीकार कर दिया गया।", "error");
        }
      });
    } else {
      this.showToast("यह ब्राउज़र नोटिफिकेशन सपोर्ट नहीं करता। इन-ऐप अलर्ट चालू रहेगा।", "info");
    }
  },

  escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  exportDataBackup() {
    const backupData = {
      version: "1.3",
      exportDate: new Date().toISOString(),
      agency: store.agency,
      newspapers: store.newspapers,
      lines: store.lines,
      customers: store.customers,
      vacations: store.vacations,
      payments: store.payments,
      billAdjustments: store.billAdjustments,
      chats: store.chats,
      feedbacks: store.feedbacks
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Newspaper_Agency_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    this.showToast("बैकअप फ़ाइल डाउनलोड हो गई!");
  },

  resetToDemoData() {
    if (confirm("क्या आप सारा डेटा रीसेट करके डिफ़ॉल्ट डेमो डेटा वापस लाना चाहते हैं?")) {
      store.resetAll();
      this.showToast("डेमो डेटा रीसेट हो गया!", "info");
      this.renderHeader();
      this.renderTab('dashboard');
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
