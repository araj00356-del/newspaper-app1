@echo off
title Newspaper Distributor App
echo Akhbar Vitrak App khol rahe hain...
start "" "file:///%~dp0index.html"
exit
