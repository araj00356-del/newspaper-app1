@echo off
title Newspaper Customer Portal
echo Grahak Portal khol rahe hain...
start "" "file:///%~dp0customer.html"
exit
